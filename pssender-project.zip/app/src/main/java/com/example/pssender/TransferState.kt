package com.example.pssender // change to match your project's package name

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/** Browser-like user agent for downloads that don't come with one (for example links shared from other apps). */
const val FALLBACK_UA =
    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

/**
 * One FTP transfer. An upload sends either a picked file ([fileUri]) or a web link that the phone downloads and
 * relays ([url]) into the folder [dir]. A download (when [remotePath] is set) copies that file from the console
 * to the phone's Downloads/PS5 folder; [remoteSize] is the size from the folder listing, or -1 when unknown.
 * [console] is the name of the console it was started for (shown on the transfer card).
 */
data class TransferRequest(
    val name: String,
    val host: String,
    val port: Int,
    val user: String,
    val pass: String,
    val dir: String,
    val fileUri: String? = null,
    val url: String? = null,
    val userAgent: String? = null,
    val cookie: String? = null,
    val remotePath: String? = null,
    val remoteSize: Long = -1L,
    val console: String = ""
)

/**
 * What the screen shows about the current (or most recent) transfer. [total] is -1 when the size is unknown.
 * [ok] is true only for a transfer that finished successfully (it is false while running and after a failure).
 * [endedAt] is the time it ended (milliseconds since 1970), or 0 while it has not ended.
 * [speed] is bytes per second (0 while not known) and [secondsLeft] the time left (-1 while not known).
 * [status] is a line about what is going on besides moving bytes (for example that the connection broke and a new try
 * is coming). [parked] means the transfer failed and the queue waits for the user: try again, or skip it.
 * [completed] counts the transfers that worked since the app started.
 */
data class TransferInfo(
    val active: Boolean = false,
    val label: String = "",
    val done: Long = 0L,
    val total: Long = -1L,
    val message: String = "",
    val download: Boolean = false,
    val ok: Boolean = false,
    val endedAt: Long = 0L,
    val console: String = "",
    val speed: Long = 0L,
    val secondsLeft: Long = -1L,
    val status: String = "",
    val parked: Boolean = false,
    val canRetry: Boolean = false,
    val completed: Int = 0
)

/**
 * Holds the queue of transfers, what the transfer card shows, and the switches for cancelling. It is also the
 * [TransferHooks] the engine reports to. The app uses the single instance [TransferState]; the tests make their own.
 */
class TransferCenter : TransferHooks {
    val info = MutableStateFlow(TransferInfo())

    /** The transfers that wait for their turn (the running one is not in it). */
    val queue = TransferQueue<TransferRequest>()

    @Volatile
    var cancelRequested = false

    /** Closes the live connections of the running transfer. Set and cleared by the engine. */
    @Volatile
    var abortHook: (() -> Unit)? = null

    private val memories = HashMap<Long, ResumeMemory>()
    private val meter = SpeedMeter()

    // ----- called from the screen -----

    /** Puts a transfer at the end of the queue. Returns true when the transfer service has to be started. */
    fun enqueue(req: TransferRequest): Boolean {
        val start = queue.add(req)
        if (start) showStarting(req)
        return start
    }

    /** The failed transfer is tried again. Returns true when the transfer service has to be started. */
    fun retry(): Boolean {
        val start = queue.retryParked()
        if (start) queue.waiting.value.firstOrNull()?.let { showStarting(it.item) }
        return start
    }

    /** The failed transfer is dropped and the queue goes on. Returns true when the transfer service has to be started. */
    fun skip(): Boolean {
        val failed = queue.parked
        val start = queue.skipParked()
        if (failed != null) discard(failed.id, true)
        if (start) {
            queue.waiting.value.firstOrNull()?.let { showStarting(it.item) }
        } else if (!info.value.active) {
            info.update { TransferInfo(completed = it.completed) }
        }
        return start
    }

    /** Takes one waiting transfer out of the queue. */
    fun removeFromQueue(id: Long) {
        if (queue.remove(id)) discard(id, true)
    }

    /** Drops everything that waits (and the failed transfer, if any). The running transfer carries on. */
    fun clearQueue() {
        for (dropped in queue.clear()) discard(dropped.id, true)
        if (!info.value.active) info.update { TransferInfo(completed = it.completed) }
    }

    /** Hides the result of a finished transfer. */
    fun clear() {
        val now = info.value
        if (!now.active && !now.parked) info.update { TransferInfo(completed = it.completed) }
    }

    /** Asks the running transfer to stop. Also closes its connections so a stalled transfer ends at once. */
    fun requestCancel() {
        cancelRequested = true
        val hook = abortHook
        if (hook != null) {
            Thread {
                try {
                    hook()
                } catch (_: Exception) {
                }
            }.start()
        }
    }

    /** The service could not be started: tell the screen, and let the next transfer ask for it again. */
    fun workerFailedToStart(message: String) {
        queue.workerFailedToStart()
        info.update { ended(it, message, false) }
    }

    // ----- called by the service's worker -----

    /** The next transfer to run, or null when nothing is left (the worker then stops). */
    fun takeNext(): QueueEntry<TransferRequest>? = queue.takeNext()

    /** [entry] starts now. */
    fun begin(entry: QueueEntry<TransferRequest>) {
        cancelRequested = false
        val req = entry.item
        info.update {
            TransferInfo(
                active = true,
                label = req.name,
                message = AppText.get(R.string.transfer_starting),
                download = req.remotePath != null,
                console = req.console,
                completed = it.completed
            )
        }
    }

    /** What the engine remembers about [id] between tries. */
    fun memoryFor(id: Long): ResumeMemory = synchronized(memories) { memories.getOrPut(id) { ResumeMemory() } }

    /**
     * [entry] ended with [result]. Returns true when the worker should go on with the next transfer, and false when it
     * should stop because the transfer failed and the queue waits for the user.
     */
    fun finishItem(entry: QueueEntry<TransferRequest>, result: TransferResult): Boolean {
        val more = queue.waitingCount > 0
        if (result.ok) {
            discard(entry.id, false)
            info.update {
                val counted = it.copy(completed = it.completed + 1)
                if (more) counted else ended(counted, result.message, true)
            }
            return true
        }
        if (result.cancelled) {
            discard(entry.id, false)
            if (!more) info.update { ended(it, result.message, false) }
            return true
        }
        queue.park(entry)
        info.update { ended(it, result.message, false).copy(parked = true, canRetry = result.retry) }
        return false
    }

    /** The service is going away. */
    fun stopped() {
        if (info.value.active) {
            requestCancel()
            info.update { ended(it, AppText.get(R.string.transfer_stopped), false) }
        }
    }

    // ----- the engine's hooks -----

    override val cancelled: Boolean get() = cancelRequested

    override fun starting(done: Long, total: Long) {
        meter.reset(done)
        info.update { it.copy(done = done, total = total, speed = 0L, secondsLeft = -1L) }
    }

    override fun progress(done: Long, total: Long) {
        meter.add(done)
        val speed = meter.bytesPerSecond()
        val left = SpeedMeter.secondsLeft(done, total, speed)
        info.update { it.copy(done = done, total = total, speed = speed, secondsLeft = left, status = "") }
    }

    override fun status(text: String) {
        info.update { it.copy(status = text) }
    }

    override fun setAbort(hook: (() -> Unit)?) {
        abortHook = hook
    }

    // ----- inside -----

    private fun showStarting(req: TransferRequest) {
        info.update {
            TransferInfo(
                active = true,
                label = req.name,
                message = AppText.get(R.string.transfer_starting),
                download = req.remotePath != null,
                console = req.console,
                completed = it.completed
            )
        }
    }

    private fun ended(from: TransferInfo, message: String, ok: Boolean): TransferInfo =
        from.copy(
            active = false, message = message, ok = ok, endedAt = System.currentTimeMillis(),
            speed = 0L, secondsLeft = -1L, status = "", parked = false, canRetry = false
        )

    /** Forgets what the engine remembered about [id] and cleans up after it (for example deletes a half-written download). */
    private fun discard(id: Long, inBackground: Boolean) {
        val memory = synchronized(memories) { memories.remove(id) } ?: return
        val job = memory.discard ?: return
        memory.discard = null
        if (inBackground) {
            Thread {
                try {
                    job()
                } catch (_: Exception) {
                }
            }.start()
        } else {
            try {
                job()
            } catch (_: Exception) {
            }
        }
    }
}

/** The one transfer center of the app, shared by the screen and the transfer service (both run in the same process). */
val TransferState = TransferCenter()

/** "3.2 MB/s, 4:05 left": what is known about how fast the running transfer goes (empty while nothing is known yet). */
fun speedAndTime(t: TransferInfo): String = speedAndTime(t.speed, t.secondsLeft)

/** The same from a speed in bytes per second (0: not known) and the seconds left (-1: not known). */
fun speedAndTime(speed: Long, secondsLeft: Long): String {
    val parts = ArrayList<String>()
    if (speed > 0L) parts.add(fmtRate(speed))
    if (secondsLeft >= 0L) parts.add(AppText.get(R.string.transfer_eta, fmtDuration(secondsLeft)))
    return joinList(parts)
}
