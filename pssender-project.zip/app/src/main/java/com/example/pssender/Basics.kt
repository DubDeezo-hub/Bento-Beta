package com.example.pssender // change to match your project's package name

// Small helpers shared by the network code and the screens. No Android parts, so they can be tested on their own.

/** Human-readable size, e.g. 1.50 GB. */
fun fmtBytes(n: Long): String = when {
    n >= 1L shl 30 -> "%.2f GB".format(n / 1073741824.0)
    n >= 1L shl 20 -> "%.1f MB".format(n / 1048576.0)
    n >= 1L shl 10 -> "%.0f KB".format(n / 1024.0)
    else -> "$n B"
}

/** "Failed: <reason>" in the app's language. Falls back to the kind of error when it carries no message. */
fun failedText(e: Exception): String = AppText.get(R.string.err_failed, e.message ?: e.javaClass.simpleName)

/** Where and how to log in to the console's FTP server. */
data class FtpSettings(val host: String, val port: Int, val user: String, val pass: String)
