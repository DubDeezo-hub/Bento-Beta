package com.example.pssender // change to match your project's package name

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------------------------
// What the file browser shows. It lives in the main screen, so the listing survives tab switches.
// ---------------------------------------------------------------------------------------------

class FilesModel {
    var path by mutableStateOf("")
    var entries by mutableStateOf<List<FtpEntry>>(emptyList())
    var busy by mutableStateOf(false)
    var message by mutableStateOf("")

    /** Bumped by [reset]; the results of jobs that started before it are thrown away. */
    private var generation = 0

    /** Forgets everything (used when another console is selected). */
    fun reset() {
        generation++
        path = ""
        entries = emptyList()
        busy = false
        message = ""
    }

    /** Opens the folder [target]. On failure the current folder stays on screen, with a message. */
    fun open(scope: CoroutineScope, s: FtpSettings, target: String, onError: () -> Unit = {}) {
        if (busy) return
        val gen = generation
        busy = true
        message = "Loading…"
        scope.launch {
            try {
                val listing = withContext(Dispatchers.IO) { ftpList(s, target) }
                if (gen == generation) {
                    path = listing.path
                    entries = listing.entries
                    message = if (listing.entries.isEmpty()) "This folder is empty." else ""
                }
            } catch (e: Exception) {
                if (gen == generation) {
                    message = ftpFailureMessage(e)
                    onError()
                }
            } finally {
                if (gen == generation) busy = false
            }
        }
    }

    /** Runs a change (rename, delete, new folder), then reloads the folder. [job] returns the message to show. */
    fun change(scope: CoroutineScope, s: FtpSettings, label: String, job: () -> String) {
        if (busy) return
        val gen = generation
        val here = path
        busy = true
        message = label
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) { job() }
            } catch (e: Exception) {
                ftpFailureMessage(e)
            }
            try {
                val listing = withContext(Dispatchers.IO) { ftpList(s, here) }
                if (gen == generation) {
                    path = listing.path
                    entries = listing.entries
                }
            } catch (_: Exception) {
            }
            if (gen == generation) {
                message = result
                busy = false
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Screens
// ---------------------------------------------------------------------------------------------

/** The FTP login fields (port, user, password, start folder). Shared by the Upload tab and the Files tab. */
@Composable
fun FtpSettingsFields(
    profile: Profile,
    update: ((Profile) -> Profile) -> Unit,
    pass: String,
    onPassChange: (String) -> Unit,
    viewedFolder: String? = null
) {
    Field("FTP port", profile.ftpPort) { v -> update { it.copy(ftpPort = v) } }
    Field("Username", profile.ftpUser) { v -> update { it.copy(ftpUser = v) } }
    Field("Password", pass, onPassChange)
    Field("Remote folder", profile.ftpDir) { v -> update { it.copy(ftpDir = v) } }
    if (viewedFolder != null && viewedFolder != profile.ftpDir) {
        TextButton(onClick = { update { it.copy(ftpDir = viewedFolder) } }) { Text("Use $viewedFolder") }
    }
}

@Composable
private fun EntryRow(e: FtpEntry, onOpen: () -> Unit, onMenu: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onOpen() }.padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (e.isDir) "📁" else if (e.isLink) "🔗" else "📄")
        Column(modifier = Modifier.weight(1f)) {
            Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (!e.isDir) Text(fmtBytes(e.size), style = MaterialTheme.typography.bodySmall)
        }
        TextButton(onClick = onMenu) { Text("⋮") }
    }
}

/**
 * Browse the console's files over FTP: open folders, rename, delete, create folders, upload into the folder
 * being viewed, and download files to the phone (downloads run in the background like uploads do).
 */
@Composable
fun FilesTab(
    model: FilesModel,
    scope: CoroutineScope,
    settings: FtpSettings?,
    profile: Profile,
    pass: String,
    onPassChange: (String) -> Unit,
    onUpdateProfile: ((Profile) -> Profile) -> Unit,
    transferActive: Boolean,
    onStart: (TransferRequest) -> Unit,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    var menuFor by remember { mutableStateOf<FtpEntry?>(null) }
    var renameFor by remember { mutableStateOf<FtpEntry?>(null) }
    var deleteFor by remember { mutableStateOf<FtpEntry?>(null) }
    var showNewFolder by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val startFolder = profile.ftpDir.trim().ifEmpty { "/" }
    val ready = settings != null && !model.busy
    val hasFolder = model.path.isNotEmpty()

    // Reload the current folder (or the start folder the first time)
    val reload: () -> Unit = {
        if (settings != null) model.open(scope, settings, if (model.path.isEmpty()) startFolder else model.path)
    }

    // Every time the tab is shown (or another console is selected) the listing is refreshed
    LaunchedEffect(profile.id) { reload() }

    // ...and again when a transfer finishes, so a new upload appears in the list
    var wasActive by remember { mutableStateOf(transferActive) }
    LaunchedEffect(transferActive) {
        if (wasActive && !transferActive && model.path.isNotEmpty()) reload()
        wasActive = transferActive
    }

    // The system Back button goes up one folder
    BackHandler(enabled = settings != null && model.path.isNotEmpty() && model.path != "/" && !model.busy) {
        if (settings != null) model.open(scope, settings, parentPath(model.path))
    }

    val uploadPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked != null && settings != null && model.path.isNotEmpty()) {
            onStart(
                TransferRequest(
                    name = ctx.contentResolver.displayName(picked),
                    host = settings.host, port = settings.port, user = settings.user, pass = settings.pass,
                    dir = model.path,
                    fileUri = picked.toString()
                )
            )
        }
    }

    // ---- dialogs ----

    menuFor?.let { e ->
        AlertDialog(
            onDismissRequest = { menuFor = null },
            title = { Text(e.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (e.isDir) "Folder" else if (e.isLink) "Link, ${fmtBytes(e.size)}" else fmtBytes(e.size),
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (!e.isDir) {
                        Button(
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !transferActive,
                            onClick = {
                                menuFor = null
                                if (settings != null) {
                                    onStart(
                                        TransferRequest(
                                            name = e.name,
                                            host = settings.host, port = settings.port,
                                            user = settings.user, pass = settings.pass,
                                            dir = "",
                                            remotePath = joinPath(model.path, e.name),
                                            remoteSize = e.size
                                        )
                                    )
                                }
                            }
                        ) { Text("Download to phone") }
                        if (transferActive) {
                            Text("Another transfer is running.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            menuFor = null
                            renameFor = e
                        }
                    ) { Text("Rename") }
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            menuFor = null
                            deleteFor = e
                        }
                    ) { Text("Delete") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuFor = null }) { Text("Close") } }
        )
    }

    renameFor?.let { e ->
        var newName by remember(e) { mutableStateOf(e.name) }
        val problem = badRemoteName(newName)
            ?: if (newName != e.name && model.entries.any { it.name == newName }) "That name is already used here." else null
        AlertDialog(
            onDismissRequest = { renameFor = null },
            title = { Text("Rename") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Field("New name", newName) { newName = it }
                    if (problem != null) Text(problem, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(
                    enabled = problem == null && newName != e.name,
                    onClick = {
                        renameFor = null
                        if (settings != null) {
                            val dir = model.path
                            model.change(scope, settings, "Renaming…") {
                                ftpRename(settings, dir, e.name, newName)
                                "Renamed ${e.name} to $newName"
                            }
                        }
                    }
                ) { Text("Rename") }
            },
            dismissButton = { TextButton(onClick = { renameFor = null }) { Text("Cancel") } }
        )
    }

    deleteFor?.let { e ->
        AlertDialog(
            onDismissRequest = { deleteFor = null },
            title = { Text("Delete ${e.name}?") },
            text = {
                Text(
                    if (e.isDir) {
                        "This deletes the folder and everything inside it from the console. It can't be undone."
                    } else {
                        "This deletes the file from the console. It can't be undone."
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    deleteFor = null
                    if (settings != null) {
                        val dir = model.path
                        model.change(scope, settings, "Deleting…") {
                            val removed = ftpDelete(settings, dir, e)
                            if (e.isDir && removed > 1) "Deleted ${e.name} and ${removed - 1} item(s) inside it" else "Deleted ${e.name}"
                        }
                    }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text("Cancel") } }
        )
    }

    if (showNewFolder) {
        var folderName by remember { mutableStateOf("") }
        val problem = if (folderName.isEmpty()) null else badRemoteName(folderName)
            ?: if (model.entries.any { it.name == folderName }) "That name is already used here." else null
        AlertDialog(
            onDismissRequest = { showNewFolder = false },
            title = { Text("New folder") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Field("Folder name", folderName) { folderName = it }
                    if (problem != null) Text(problem, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(
                    enabled = folderName.isNotEmpty() && problem == null,
                    onClick = {
                        showNewFolder = false
                        if (settings != null) {
                            val dir = model.path
                            model.change(scope, settings, "Creating folder…") {
                                ftpMakeDir(settings, dir, folderName)
                                "Created the folder $folderName"
                            }
                        }
                    }
                ) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showNewFolder = false }) { Text("Cancel") } }
        )
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("FTP settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FtpSettingsFields(profile, onUpdateProfile, pass, onPassChange, model.path.ifEmpty { null })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showSettings = false
                    model.reset()
                    reload()
                }) { Text("Done") }
            }
        )
    }

    // ---- screen ----

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(if (hasFolder) model.path else "Not loaded yet", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(
                enabled = ready && hasFolder && model.path != "/",
                onClick = { if (settings != null) model.open(scope, settings, parentPath(model.path)) }
            ) { Text("⬆ Up") }
            TextButton(enabled = ready, onClick = { reload() }) { Text("Refresh") }
            TextButton(enabled = ready && hasFolder, onClick = { showNewFolder = true }) { Text("New folder") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(
                enabled = ready && hasFolder && !transferActive,
                onClick = { uploadPicker.launch(arrayOf("*/*")) }
            ) { Text("Upload here") }
            TextButton(onClick = { showSettings = true }) { Text("FTP settings") }
        }
        if (model.busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        if (settings == null) {
            Text("Enter the console IP and a valid FTP port to browse its files.", style = MaterialTheme.typography.bodySmall)
        } else if (model.message.isNotEmpty()) {
            Text(model.message, style = MaterialTheme.typography.bodySmall)
        }
        LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
            items(model.entries) { e ->
                EntryRow(
                    e,
                    onOpen = {
                        if (settings != null && !model.busy) {
                            when {
                                e.isDir -> model.open(scope, settings, joinPath(model.path, e.name))
                                // A link might lead to a folder: try it, and offer the actions if it isn't one
                                e.isLink -> model.open(scope, settings, joinPath(model.path, e.name), onError = { menuFor = e })
                                else -> menuFor = e
                            }
                        }
                    },
                    onMenu = { menuFor = e }
                )
            }
        }
    }
}
