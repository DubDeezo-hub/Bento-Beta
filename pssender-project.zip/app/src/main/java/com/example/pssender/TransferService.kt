package com.example.pssender // change to match your project's package name

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Browser-like user agent for downloads that don't come with one (for example links shared from other apps). */
const val FALLBACK_UA =
    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

/**
 * One FTP transfer. An upload sends either a picked file ([fileUri]) or a web link that the phone downloads and
 * relays ([url]) into the folder [dir]. A download (when [remotePath] is set) copies that file from the console
 * to the phone's Downloads/PS5 folder; [remoteSize] is the size from the folder listing, or -1 when unknown.
 */
data class TransferRequest(
    val name: String,
    val host: String,
    val port: Int,
    val user: String,
    val pass: String,
    val dir: String,
    val fileUri: String? = null,
    val url: String? = null,
    val userAgent: String? = null,
    val cookie: String? = null,
    val remotePath: String? = null,
    val remoteSize: Long = -1L
)

/** What the screen shows about the current (or most recent) transfer. [total] is -1 when the size is unknown. */
data class TransferInfo(
    val active: Boolean = false,
    val label: String = "",
    val done: Long = 0L,
    val total: Long = -1L,
    val message: String = "",
    val download: Boolean = false
)

/** Shared between the screen and the service; both run in the same process. */
object TransferState {
    val info = MutableStateFlow(TransferInfo())

    @Volatile
    var cancelRequested = false

    /** Closes the live connections of the running transfer. Set and cleared by the FTP code. */
    @Volatile
    var abortHook: (() -> Unit)? = null

    @Volatile
    private var request: TransferRequest? = null

    fun begin(req: TransferRequest) {
        cancelRequested = false
        request = req
        info.value = TransferInfo(active = true, label = req.name, message = "Starting…", download = req.remotePath != null)
    }

    fun takeRequest(): TransferRequest? {
        val r = request
        request = null
        return r
    }

    fun progress(done: Long, total: Long) {
        info.update { it.copy(done = done, total = total) }
    }

    fun finish(message: String) {
        info.update { it.copy(active = false, message = message) }
    }

    /** Hides the result of a finished transfer. */
    fun clear() {
        if (!info.value.active) info.value = TransferInfo()
    }

    /** Asks the running transfer to stop. Also closes its connections so a stalled transfer ends at once. */
    fun requestCancel() {
        cancelRequested = true
        val hook = abortHook
        if (hook != null) {
            Thread {
                try {
                    hook()
                } catch (_: Exception) {
                }
            }.start()
        }
    }
}

/**
 * Runs one FTP transfer (upload or download) as a foreground service, so it keeps going when the app is in the
 * background or the screen is off. Progress is published through [TransferState] and a notification with a
 * Cancel button.
 */
class TransferService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(CHANNEL_ID, "PS5 transfers", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            TransferState.requestCancel()
            if (!TransferState.info.value.active) stopSelf(startId)
            return START_NOT_STICKY
        }
        val req = TransferState.takeRequest()
        // Must be called promptly after startForegroundService()
        startForeground(
            NOTIF_ID,
            buildNotification(req?.name ?: "Transfer", 0L, -1L, null, true, req?.remotePath != null),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        if (req == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        scope.launch { runTransfer(req, startId) }
        return START_NOT_STICKY
    }

    private fun runTransfer(req: TransferRequest, startId: Int) {
        val onProgress: (Long, Long) -> Unit = { done, total ->
            TransferState.progress(done, total)
            notifyUser(buildNotification(req.name, done, total, null, true, req.remotePath != null))
        }
        val result = try {
            if (req.remotePath != null) {
                ftpDownloadToPhone(
                    contentResolver, req.remotePath, req.name, req.remoteSize,
                    FtpSettings(req.host, req.port, req.user, req.pass), onProgress
                )
            } else if (req.fileUri != null) {
                val uri = Uri.parse(req.fileUri)
                val stream = contentResolver.openInputStream(uri)
                if (stream == null) {
                    "Could not open the file"
                } else {
                    stream.use {
                        ftpUploadStream(
                            it, fileSize(contentResolver, uri), req.name,
                            req.host, req.port, req.user, req.pass, req.dir, onProgress
                        )
                    }
                }
            } else {
                ftpUploadFromUrl(
                    req.url.orEmpty(), req.userAgent ?: FALLBACK_UA, req.cookie, req.name,
                    req.host, req.port, req.user, req.pass, req.dir, onProgress
                )
            }
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
        TransferState.finish(result)
        // Keep the notification, but turn it into a plain result message that can be swiped away
        stopForeground(Service.STOP_FOREGROUND_DETACH)
        notifyUser(buildNotification(req.name, 0L, 0L, result, false, req.remotePath != null))
        stopSelf(startId)
    }

    private fun buildNotification(
        name: String, done: Long, total: Long, result: String?, ongoing: Boolean, download: Boolean
    ): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(
                when {
                    download && ongoing -> android.R.drawable.stat_sys_download
                    download -> android.R.drawable.stat_sys_download_done
                    ongoing -> android.R.drawable.stat_sys_upload
                    else -> android.R.drawable.stat_sys_upload_done
                }
            )
            .setContentTitle(name)
            .setContentIntent(open)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
        if (ongoing) {
            val unknown = total <= 0L
            val percent = if (unknown) 0 else (done * 100 / total).toInt()
            val moved = if (download) "received" else "sent"
            builder.setContentText(if (unknown) "${fmtBytes(done)} $moved" else "$percent%  ·  ${fmtBytes(done)} of ${fmtBytes(total)}")
            builder.setProgress(100, percent, unknown)
            val cancel = PendingIntent.getService(
                this, 1,
                Intent(this, TransferService::class.java).setAction(ACTION_CANCEL),
                PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(0, "Cancel", cancel)
        } else {
            builder.setContentText(result ?: "")
            builder.setAutoCancel(true)
        }
        return builder.build()
    }

    private fun notifyUser(n: Notification) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
    }

    override fun onDestroy() {
        if (TransferState.info.value.active) {
            TransferState.requestCancel()
            TransferState.finish("Stopped")
        }
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "transfers"
        const val NOTIF_ID = 42
        const val ACTION_CANCEL = "com.example.pssender.CANCEL"

        /** Starts a background FTP transfer (upload or download). Progress shows in [TransferState] and in a notification. */
        fun start(ctx: Context, req: TransferRequest) {
            TransferState.begin(req)
            try {
                ctx.startForegroundService(Intent(ctx, TransferService::class.java))
            } catch (e: Exception) {
                TransferState.finish("Couldn't start the transfer: ${e.message}")
            }
        }
    }
}
