package com.example.pssender // change to match your project's package name

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** The longest the phone is kept awake for one run of transfers (a safety net: the locks are normally let go much earlier). */
internal const val LOCK_MAX_MS = 12L * 60L * 60L * 1000L

/**
 * Keeps the processor and the Wi-Fi radio awake while transfers run. Without them Android may slow the Wi-Fi down or
 * pause the app a few minutes after the screen goes off, which makes a long transfer crawl or drop.
 */
internal class TransferLocks(ctx: Context) {
    private val wake: PowerManager.WakeLock? = try {
        ctx.getSystemService(PowerManager::class.java)?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "pssender:transfer")
    } catch (_: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    private val wifi: WifiManager.WifiLock? = try {
        ctx.applicationContext.getSystemService(WifiManager::class.java)
            ?.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "pssender:transfer")
    } catch (_: Exception) {
        null
    }

    fun acquire() {
        try {
            wake?.acquire(LOCK_MAX_MS)
        } catch (_: Exception) {
        }
        try {
            wifi?.acquire()
        } catch (_: Exception) {
        }
    }

    fun release() {
        try {
            if (wake?.isHeld == true) wake.release()
        } catch (_: Exception) {
        }
        try {
            if (wifi?.isHeld == true) wifi.release()
        } catch (_: Exception) {
        }
    }
}

/**
 * Works through the queue of FTP transfers (uploads and downloads) as a foreground service, so it keeps going when the
 * app is in the background or the screen is off. Progress is published through [TransferState] and a notification with
 * a Cancel button. The service runs while there is something to do and stops itself when the queue is empty or
 * waits for the user after a failed transfer.
 */
class TransferService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastStartId = 0
    private var lastNotified = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(CHANNEL_ID, AppText.get(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId = startId
        if (intent?.action == ACTION_CANCEL) {
            // From the notification: everything stops, not only the running transfer
            TransferState.clearQueue()
            TransferState.requestCancel()
            if (!TransferState.queue.isWorking) stopSelf(startId)
            return START_NOT_STICKY
        }
        // Must be called promptly after startForegroundService()
        startForeground(
            NOTIF_ID,
            buildNotification(TransferState.info.value),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        // One worker for each time the queue asked for the service to be started
        scope.launch { work() }
        return START_NOT_STICKY
    }

    /** Runs the queued transfers one after the other until none is left or one fails and the queue has to wait. */
    private suspend fun work() {
        val locks = TransferLocks(this)
        locks.acquire()
        val watcher = scope.launch { watchProgress() }
        try {
            while (true) {
                val entry = TransferState.takeNext() ?: break
                TransferState.begin(entry)
                val result: TransferResult = try {
                    runTransfer(entry)
                } catch (e: Exception) {
                    TransferResult(false, describeFailure(e), retry = isTransientFailure(e))
                }
                if (!TransferState.finishItem(entry, result)) break
            }
        } finally {
            watcher.cancel()
            locks.release()
            mainHandler.post { workerEnded() }
        }
    }

    private fun runTransfer(entry: QueueEntry<TransferRequest>): TransferResult {
        val req = entry.item
        val memory = TransferState.memoryFor(entry.id)
        val settings = FtpSettings(req.host, req.port, req.user, req.pass)
        return when {
            req.remotePath != null ->
                ftpDownloadToPhone(contentResolver, req.remotePath, req.name, req.remoteSize, settings, memory, TransferState)
            req.fileUri != null ->
                ftpUploadPicked(contentResolver, Uri.parse(req.fileUri), req.name, settings, req.dir, memory, TransferState)
            else ->
                ftpUploadFromUrl(
                    req.url.orEmpty(), req.userAgent ?: FALLBACK_UA, req.cookie, req.name, settings, req.dir,
                    memory, TransferState
                )
        }
    }

    /** Keeps the notification up to date (at most once a second) while a transfer runs. */
    private suspend fun watchProgress() {
        TransferState.info.collect { t ->
            if (t.active) {
                val now = System.nanoTime() / 1_000_000L
                if (now - lastNotified >= 1000L) {
                    lastNotified = now
                    notifyUser(buildNotification(t))
                }
            }
        }
    }

    /** Runs on the main thread after a worker is done. Stops the service unless a new worker was ordered meanwhile. */
    private fun workerEnded() {
        if (TransferState.queue.isWorking) return // a new start command is on its way
        // Keep the notification, but turn it into a plain result message that can be swiped away
        stopForeground(Service.STOP_FOREGROUND_DETACH)
        notifyUser(buildNotification(TransferState.info.value))
        stopSelf(lastStartId)
    }

    /** The small line under the title: speed, time left and how many transfers wait behind this one. */
    private fun subLine(t: TransferInfo): String {
        val parts = ArrayList<String>()
        val speed = speedAndTime(t)
        if (speed.isNotEmpty()) parts.add(speed)
        val waiting = TransferState.queue.waitingCount
        if (waiting > 0) parts.add(AppText.get(R.string.transfer_queued, waiting))
        return joinList(parts)
    }

    private fun buildNotification(t: TransferInfo): Notification {
        val ongoing = t.active
        val name = t.label.ifEmpty { AppText.get(R.string.transfer_default_name) }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(
                when {
                    t.download && ongoing -> android.R.drawable.stat_sys_download
                    t.download -> android.R.drawable.stat_sys_download_done
                    ongoing -> android.R.drawable.stat_sys_upload
                    else -> android.R.drawable.stat_sys_upload_done
                }
            )
            .setContentTitle(name)
            .setContentIntent(open)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
        if (ongoing) {
            val unknown = t.total <= 0L
            val percent = if (unknown) 0 else (t.done * 100 / t.total).toInt().coerceIn(0, 100)
            builder.setContentText(
                when {
                    t.status.isNotEmpty() -> t.status
                    !unknown -> AppText.get(
                        R.string.transfer_detail_total,
                        AppText.get(R.string.percent_value, percent), fmtBytes(t.done), fmtBytes(t.total)
                    )
                    t.download -> AppText.get(R.string.notif_received, fmtBytes(t.done))
                    else -> AppText.get(R.string.notif_sent, fmtBytes(t.done))
                }
            )
            builder.setProgress(100, percent, unknown)
            val extra = subLine(t)
            if (extra.isNotEmpty()) builder.setSubText(extra)
            val cancel = PendingIntent.getService(
                this, 1,
                Intent(this, TransferService::class.java).setAction(ACTION_CANCEL),
                PendingIntent.FLAG_IMMUTABLE
            )
            val label = if (TransferState.queue.waitingCount > 0) R.string.action_cancel_all else R.string.action_cancel
            builder.addAction(0, AppText.get(label), cancel)
        } else {
            builder.setContentText(t.message)
            builder.setAutoCancel(true)
        }
        return builder.build()
    }

    private fun notifyUser(n: Notification) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
    }

    override fun onDestroy() {
        TransferState.stopped()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "transfers"
        const val NOTIF_ID = 42
        const val ACTION_CANCEL = "com.example.pssender.CANCEL"

        /**
         * Puts a transfer in the queue and starts the service if it isn't busy. Progress shows in [TransferState] and in a
         * notification. Returns true when the transfer starts right away, false when it has to wait its turn.
         */
        fun enqueue(ctx: Context, req: TransferRequest): Boolean {
            val startsNow = TransferState.enqueue(req)
            if (startsNow) startWorker(ctx)
            return startsNow
        }

        /** Tries the failed transfer again and goes on with the queue. */
        fun retry(ctx: Context) {
            if (TransferState.retry()) startWorker(ctx)
        }

        /** Drops the failed transfer and goes on with the queue. */
        fun skip(ctx: Context) {
            if (TransferState.skip()) startWorker(ctx)
        }

        private fun startWorker(ctx: Context) {
            try {
                ctx.startForegroundService(Intent(ctx, TransferService::class.java))
            } catch (e: Exception) {
                TransferState.workerFailedToStart(AppText.get(R.string.transfer_start_failed, e.message ?: e.javaClass.simpleName))
            }
        }
    }
}
