package com.example.pssender // change to match your project's package name

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream

// ---------------------------------------------------------------------------------------------
// Storage: payloads kept inside the app, so they can be sent again without picking a file
// ---------------------------------------------------------------------------------------------

/** Largest payload the shelf accepts. Payloads are small; this stops a huge file being copied in by mistake. */
const val SHELF_MAX_BYTES = 64L * 1024 * 1024

data class ShelfItem(val name: String, val size: Long)

data class ShelfAdded(val name: String, val size: Long, val replaced: Boolean)

class ShelfTooLarge(val limit: Long) : IOException("File is larger than $limit bytes")

fun shelfDir(ctx: Context): File = File(ctx.filesDir, "payloads").also { it.mkdirs() }

/** A file name that is safe to store: no folders, no odd characters, never empty. */
fun safeShelfName(raw: String): String {
    val last = raw.substringAfterLast('/').substringAfterLast('\\')
    val cleaned = last.map { c -> if (c.isISOControl() || c in "\\/:*?\"<>|") '_' else c }
        .joinToString("")
        .trim()
        .trimStart('.')
        .take(100)
        .trim()
    return cleaned.ifBlank { "payload.bin" }
}

/**
 * Copies [input] onto the shelf as [rawName]. A payload with the same name is replaced (handy for updating one),
 * but only once the new copy is complete. Throws [ShelfTooLarge] past [maxBytes].
 */
fun shelfAdd(dir: File, rawName: String, input: InputStream, maxBytes: Long = SHELF_MAX_BYTES): ShelfAdded {
    dir.mkdirs()
    val name = safeShelfName(rawName)
    val target = File(dir, name)
    val temp = File(dir, ".adding-$name")
    var size = 0L
    try {
        FileOutputStream(temp).use { out ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                size += n
                if (size > maxBytes) throw ShelfTooLarge(maxBytes)
                out.write(buf, 0, n)
            }
        }
        if (size == 0L) throw IOException("The file is empty")
        val replaced = target.exists()
        if (replaced) target.delete()
        if (!temp.renameTo(target)) throw IOException("Couldn't save $name")
        return ShelfAdded(name, size, replaced)
    } finally {
        temp.delete()
    }
}

/** Everything on the shelf, alphabetical. Unfinished copies (names starting with a dot) are left out. */
fun shelfList(dir: File): List<ShelfItem> =
    dir.listFiles().orEmpty()
        .filter { it.isFile && !it.name.startsWith(".") }
        .map { ShelfItem(it.name, it.length()) }
        .sortedBy { it.name.lowercase() }

/** Deletes one payload from the shelf. Only plain names inside the shelf folder are accepted. */
fun shelfRemove(dir: File, name: String): Boolean {
    val f = File(dir, name)
    return f.parentFile == dir && f.isFile && f.delete()
}

fun shelfAddedMessage(a: ShelfAdded): String =
    "${if (a.replaced) "Updated" else "Added"} on the shelf: ${a.name} (${fmtBytes(a.size)})"

fun shelfTooLargeMessage(limit: Long): String =
    "That file is bigger than ${fmtBytes(limit)}, so it wasn't added to the shelf."

/** Copies a file picked with the system file picker onto the shelf. Returns a message for the status line. */
suspend fun shelfAddFromUri(ctx: Context, uri: Uri): String =
    withContext(Dispatchers.IO) {
        try {
            val name = ctx.contentResolver.displayName(uri)
            val input = ctx.contentResolver.openInputStream(uri) ?: return@withContext "Could not open the file"
            shelfAddedMessage(input.use { shelfAdd(shelfDir(ctx), name, it) })
        } catch (e: ShelfTooLarge) {
            shelfTooLargeMessage(e.limit)
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
    }

// ---------------------------------------------------------------------------------------------
// Payload tab
// ---------------------------------------------------------------------------------------------

/**
 * The shelf (saved payloads with one-tap Send) plus the old "pick a file and send it once" flow.
 * [shelfVersion] changes whenever something else adds to the shelf, so the list reloads.
 */
@Composable
fun PayloadTab(host: String, port: String, onPortChange: (String) -> Unit, shelfVersion: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var shelf by remember(shelfVersion) { mutableStateOf(shelfList(shelfDir(ctx))) }
    var oneOff by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Idle") }
    var removing by remember { mutableStateOf<ShelfItem?>(null) }
    val canSend = host.isNotBlank() && port.trim().toIntOrNull() != null

    val adder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked != null) {
            status = "Adding to the shelf…"
            scope.launch {
                status = shelfAddFromUri(ctx, picked)
                shelf = shelfList(shelfDir(ctx))
            }
        }
    }
    val oneOffPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { oneOff = it }

    removing?.let { item ->
        AlertDialog(
            onDismissRequest = { removing = null },
            title = { Text("Remove ${item.name}?") },
            text = { Text("It is deleted from the shelf. The original file on your phone isn't touched.") },
            confirmButton = {
                TextButton(onClick = {
                    shelfRemove(shelfDir(ctx), item.name)
                    shelf = shelfList(shelfDir(ctx))
                    removing = null
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { removing = null }) { Text("Cancel") } }
        )
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Field("Loader port", port, onPortChange)

        Text("Payload shelf", style = MaterialTheme.typography.titleMedium)
        if (shelf.isEmpty()) {
            Text(
                "Nothing saved yet. Add the payloads you use often (an FTP server, etaHEN, ...) and send each with one tap. " +
                    "You can also save one straight from the Web tab when you download it.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        shelf.forEach { item ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(fmtBytes(item.size), style = MaterialTheme.typography.bodySmall)
                }
                Button(
                    enabled = canSend,
                    onClick = {
                        status = "Sending ${item.name}…"
                        scope.launch {
                            status = "${item.name}: " +
                                sendPayloadFile(File(shelfDir(ctx), item.name), host.trim(), port.trim().toInt())
                        }
                    }
                ) { Text("Send") }
                TextButton(onClick = { removing = item }) { Text("Remove") }
            }
        }
        Button(onClick = { adder.launch(arrayOf("*/*")) }) { Text("Add payload to shelf") }

        Text("Send a file once", style = MaterialTheme.typography.titleMedium)
        Button(onClick = { oneOffPicker.launch(arrayOf("*/*")) }) { Text("Choose payload (.elf / .bin)") }
        Text(oneOff?.let { ctx.contentResolver.displayName(it) } ?: "No file chosen")
        Button(
            enabled = canSend && oneOff != null,
            onClick = {
                status = "Sending…"
                scope.launch { status = sendPayload(ctx.contentResolver, oneOff!!, host.trim(), port.trim().toInt()) }
            }
        ) { Text("Send payload") }
        Text(status)
    }
}
