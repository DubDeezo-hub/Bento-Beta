package com.example.pssender // change to match your project's package name

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { SenderApp() } }
    }
}

@Composable
fun SenderApp() {
    var host by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Install", "Payload", "Upload")

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("PS5 Sender", style = MaterialTheme.typography.headlineSmall)
        Field("Console IP", host) { host = it }
        TabRow(selectedTabIndex = tab) {
            tabs.forEachIndexed { i, title ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
            }
        }
        when (tab) {
            0 -> InstallTab(host)
            1 -> PayloadTab(host)
            else -> UploadTab(host)
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun InstallTab(host: String) {
    val scope = rememberCoroutineScope()
    var port by remember { mutableStateOf("12800") } // etaHEN installer service port
    var pkgUrl by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Idle") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Field("Installer port (etaHEN: 12800)", port) { port = it }
        Field("Package URL", pkgUrl) { pkgUrl = it }
        Button(
            enabled = host.isNotBlank() && pkgUrl.isNotBlank(),
            onClick = {
                status = "Sending…"
                scope.launch { status = sendInstall(host.trim(), port.trim(), pkgUrl.trim()) }
            }
        ) { Text("Send") }
        Text(status)
    }
}

@Composable
fun PayloadTab(host: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var port by remember { mutableStateOf("9021") } // common ELF-loader port; check your loader
    var uri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Idle") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri = it }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Field("Loader port", port) { port = it }
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Choose payload (.elf / .bin)") }
        Text(uri?.let { ctx.contentResolver.displayName(it) } ?: "No file chosen")
        Button(
            enabled = host.isNotBlank() && uri != null && port.toIntOrNull() != null,
            onClick = {
                status = "Sending…"
                scope.launch { status = sendPayload(ctx.contentResolver, uri!!, host.trim(), port.toInt()) }
            }
        ) { Text("Send payload") }
        Text(status)
    }
}

@Composable
fun UploadTab(host: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var port by remember { mutableStateOf("2121") } // common console FTP port; check your FTP server
    var user by remember { mutableStateOf("anonymous") }
    var pass by remember { mutableStateOf("") }
    var dir by remember { mutableStateOf("/data") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Idle") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri = it }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Field("FTP port", port) { port = it }
        Field("Username", user) { user = it }
        Field("Password", pass) { pass = it }
        Field("Remote folder", dir) { dir = it }
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Choose file") }
        Text(uri?.let { ctx.contentResolver.displayName(it) } ?: "No file chosen")
        Button(
            enabled = host.isNotBlank() && uri != null && port.toIntOrNull() != null,
            onClick = {
                status = "Uploading…"
                scope.launch {
                    status = ftpUpload(
                        ctx.contentResolver, uri!!, host.trim(), port.toInt(),
                        user.trim(), pass, dir.trim()
                    )
                }
            }
        ) { Text("Upload") }
        Text(status)
    }
}
