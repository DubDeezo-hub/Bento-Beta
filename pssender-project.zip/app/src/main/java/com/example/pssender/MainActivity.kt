package com.example.pssender // change to match your project's package name

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch

/** Starting homepage for the Web tab. It can be changed inside the app. */
const val DEFAULT_HOME = "https://www.superpsx.com/category/ps5/ps5-games/"

class MainActivity : ComponentActivity() {
    /** A link another app shared to us; the screen consumes it and sets it back to null. */
    private var sharedLink by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Only on a fresh start: after a rotation the same intent would otherwise be handled twice
        if (savedInstanceState == null) readShare(intent)
        setContent { MaterialTheme { SenderApp(sharedLink) { sharedLink = null } } }
    }

    // The app is already open when something is shared to it
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readShare(intent)
    }

    private fun readShare(source: Intent?) {
        val i = source ?: return
        if (i.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        sharedLink = Regex("""https?://\S+""").find(text)?.value
    }
}

/** A text setting that is loaded from, and saved to, SharedPreferences whenever it changes. */
@Composable
fun rememberPref(key: String, default: String): MutableState<String> {
    val prefs = LocalContext.current.getSharedPreferences("settings", Context.MODE_PRIVATE)
    val state = remember { mutableStateOf(prefs.getString(key, default) ?: default) }
    LaunchedEffect(state.value) { prefs.edit().putString(key, state.value).apply() }
    return state
}

/** Reads a saved setting without composing, for use inside button handlers. */
fun readPref(ctx: Context, key: String, default: String): String =
    ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).getString(key, default) ?: default

fun normalizeUrl(input: String): String {
    val t = input.trim()
    return if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
}

/** Sites the user has agreed to open during this session (plus the homepage's own site). */
val allowedSites = mutableSetOf<String>()

/** Rough "site" of a host, e.g. www.superpsx.com -> superpsx.com. Good enough to spot jumps to another site. */
fun siteOf(host: String?): String {
    val parts = (host ?: "").lowercase().split('.')
    if (parts.size <= 2) return parts.joinToString(".")
    val secondLevel = setOf("co", "com", "org", "net", "gov", "ac")
    val keep = if (parts.last().length == 2 && parts[parts.size - 2] in secondLevel) 3 else 2
    return parts.takeLast(keep).joinToString(".")
}

/** True when [target] is on a different site than the page currently shown and the user hasn't allowed it. */
fun isOffSite(view: WebView?, target: Uri): Boolean {
    val from = siteOf(view?.url?.let { Uri.parse(it).host })
    val to = siteOf(target.host)
    return from.isNotEmpty() && to.isNotEmpty() && from != to && to !in allowedSites
}

/** A download (or shared link) waiting for the user to choose where it should go. */
data class PendingDownload(
    val url: String,
    val userAgent: String,
    val contentDisposition: String?,
    val mimeType: String?
)

/** Saves a download to the phone's Downloads folder with the system download manager. */
fun saveToPhone(ctx: Context, d: PendingDownload) {
    val req = DownloadManager.Request(Uri.parse(d.url))
        .setMimeType(d.mimeType)
        .addRequestHeader("User-Agent", d.userAgent)
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setDestinationInExternalPublicDir(
            Environment.DIRECTORY_DOWNLOADS,
            URLUtil.guessFileName(d.url, d.contentDisposition, d.mimeType)
        )
    CookieManager.getInstance().getCookie(d.url)?.let { req.addRequestHeader("Cookie", it) }
    (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
    Toast.makeText(ctx, "Download started (see Downloads)", Toast.LENGTH_SHORT).show()
}

@SuppressLint("SetJavaScriptEnabled")
fun buildWebView(
    ctx: Context, startUrl: String,
    onCanGoBack: (Boolean) -> Unit,
    onOffSite: (String) -> Unit,
    onDownload: (PendingDownload) -> Unit
): WebView {
    val web = WebView(ctx)
    web.settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        setSupportMultipleWindows(true)
        // Some sites treat the default "wv" (WebView) user agent as a bot and break their links
        userAgentString = userAgentString.replace("; wv", "")
    }
    CookieManager.getInstance().apply {
        setAcceptCookie(true)
        setAcceptThirdPartyCookies(web, true)
    }

    web.webViewClient = object : WebViewClient() {
        // http(s) links load inside the WebView; other schemes (market:, intent:, ...) go to the system
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val uri = request?.url ?: return false
            if (uri.scheme == "http" || uri.scheme == "https") {
                // Ads often hijack a tap and bounce to another site: ask before leaving the current one
                if (request?.isForMainFrame == true && isOffSite(view, uri)) {
                    onOffSite(uri.toString())
                    return true
                }
                return false
            }
            try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
            }
            return true
        }

        override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
            onCanGoBack(view?.canGoBack() == true)
        }

        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
            if (request?.isForMainFrame == true) {
                Toast.makeText(ctx, "Couldn't load page: ${error?.description}", Toast.LENGTH_LONG).show()
            }
        }

        override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
            if (request?.isForMainFrame == true) {
                Toast.makeText(ctx, "Site replied HTTP ${errorResponse?.statusCode}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Links that open a "new window" (target=_blank) load in this same WebView; automatic popups are ignored.
    web.webChromeClient = object : WebChromeClient() {
        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
            if (!isUserGesture) return false
            val main = view ?: return false
            val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
            val popup = WebView(main.context)
            popup.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                    request?.url?.let { u ->
                        if (isOffSite(main, u)) onOffSite(u.toString()) else main.loadUrl(u.toString())
                    }
                    v?.destroy()
                    return true
                }
            }
            transport.webView = popup
            resultMsg?.sendToTarget()
            return true
        }
    }

    // WebView doesn't download files by itself: ask the app where the file should go.
    web.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
        onDownload(PendingDownload(url, userAgent, contentDisposition, mimeType))
    }

    web.loadUrl(startUrl)
    return web
}

@Composable
fun SenderApp(sharedLink: String? = null, onSharedConsumed: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var host by rememberPref("host", "")
    var homeUrl by rememberPref("home_url_v2", DEFAULT_HOME)
    var ftpPass by remember { mutableStateOf("") } // not saved
    var tab by remember { mutableStateOf(0) }
    var webCanGoBack by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<PendingDownload?>(null) }
    var offSiteUrl by remember { mutableStateOf<String?>(null) }
    var statusLine by remember { mutableStateOf("") }
    var testResult by remember { mutableStateOf("") }
    val transfer by TransferState.info.collectAsState()
    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    // One WebView for the whole session, so the page survives switching tabs.
    val webView = remember {
        allowedSites.add(siteOf(Uri.parse(homeUrl).host))
        buildWebView(ctx, homeUrl, { webCanGoBack = it }, { offSiteUrl = it }) { pending = it }
    }
    val tabs = listOf("Install", "Payload", "Upload", "Web")

    // A link shared from another app goes through the same chooser as a download from the Web tab
    LaunchedEffect(sharedLink) {
        if (sharedLink != null) {
            pending = PendingDownload(sharedLink, FALLBACK_UA, null, null)
            onSharedConsumed()
        }
    }

    // Starts a background FTP transfer (one at a time) and asks for notification permission the first time
    val startTransfer: (TransferRequest) -> Unit = { req ->
        if (TransferState.info.value.active) {
            statusLine = "A transfer is already running. Wait for it to finish or cancel it first."
        } else {
            if (Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            statusLine = ""
            TransferService.start(ctx, req)
        }
    }

    BackHandler(enabled = tab == 3 && webCanGoBack) { webView.goBack() }

    offSiteUrl?.let { u ->
        val site = siteOf(Uri.parse(u).host)
        AlertDialog(
            onDismissRequest = { offSiteUrl = null },
            title = { Text("Leave this site?") },
            text = {
                Text(
                    "The page wants to open $site. Ads often trigger this when you tap a link, " +
                        "so only continue if you expected it."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    allowedSites.add(site)
                    offSiteUrl = null
                    webView.loadUrl(u)
                }) { Text("Open") }
            },
            dismissButton = { TextButton(onClick = { offSiteUrl = null }) { Text("Block") } }
        )
    }

    pending?.let { d ->
        val name = URLUtil.guessFileName(d.url, d.contentDisposition, d.mimeType)

        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text(name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            pending = null
                            if (host.isBlank()) {
                                statusLine = "Enter the Console IP first."
                            } else {
                                statusLine = "Sending link to PS5…"
                                scope.launch {
                                    statusLine = sendInstall(host.trim(), readPref(ctx, "install_port", "12800").trim(), d.url)
                                }
                            }
                        }
                    ) { Text("Send link to PS5 installer") }
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            pending = null
                            val port = readPref(ctx, "ftp_port", "2121").trim().toIntOrNull()
                            if (host.isBlank() || port == null) {
                                statusLine = "Check the Console IP and FTP port."
                            } else {
                                startTransfer(
                                    TransferRequest(
                                        name = name,
                                        host = host.trim(),
                                        port = port,
                                        user = readPref(ctx, "ftp_user", "anonymous").trim(),
                                        pass = ftpPass,
                                        dir = readPref(ctx, "ftp_dir", "/data").trim(),
                                        url = d.url,
                                        userAgent = d.userAgent,
                                        cookie = CookieManager.getInstance().getCookie(d.url)
                                    )
                                )
                            }
                        }
                    ) { Text("Upload to PS5 (FTP)") }
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            pending = null
                            saveToPhone(ctx, d)
                        }
                    ) { Text("Save to phone") }
                    Text(
                        "The installer needs a direct package link the console can open without logging in. " +
                            "FTP works for any file and keeps your login session. The phone relays the data " +
                            "in the background, with progress under the tabs and in a notification.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancel") } }
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("PS5 Sender", style = MaterialTheme.typography.headlineSmall)
        Field("Console IP", host) { host = it }
        if (tab != 3) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Button(
                    enabled = host.isNotBlank(),
                    onClick = {
                        testResult = "Testing…"
                        scope.launch {
                            testResult = testConnection(
                                host.trim(),
                                listOf(
                                    "Installer" to readPref(ctx, "install_port", "12800").trim().toIntOrNull(),
                                    "Loader" to readPref(ctx, "payload_port", "9021").trim().toIntOrNull(),
                                    "FTP" to readPref(ctx, "ftp_port", "2121").trim().toIntOrNull()
                                )
                            )
                        }
                    }
                ) { Text("Test connection") }
                if (testResult.isNotEmpty()) {
                    Text(testResult, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        TabRow(selectedTabIndex = tab) {
            tabs.forEachIndexed { i, title ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
            }
        }
        if (statusLine.isNotEmpty()) {
            Text(statusLine, style = MaterialTheme.typography.bodySmall)
        }
        TransferBar(transfer, onCancel = { TransferState.requestCancel() }, onDismiss = { TransferState.clear() })
        if (tab == 3) {
            WebTab(
                webView, homeUrl,
                { allowedSites.add(siteOf(Uri.parse(it).host)); homeUrl = it },
                Modifier.weight(1f)
            )
        } else {
            // The form tabs scroll, so nothing is cut off on small screens
            Column(
                modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (tab) {
                    0 -> InstallTab(host)
                    1 -> PayloadTab(host)
                    else -> UploadTab(host, ftpPass, { ftpPass = it }, startTransfer)
                }
            }
        }
    }
}

/** Progress of the current background transfer, with Cancel while it runs and Dismiss once it's done. */
@Composable
fun TransferBar(t: TransferInfo, onCancel: () -> Unit, onDismiss: () -> Unit) {
    if (t.label.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (t.active) {
            val line = if (t.total > 0) {
                "${t.label}: ${t.done * 100 / t.total}% (${fmtBytes(t.done)} of ${fmtBytes(t.total)})"
            } else {
                "${t.label}: ${fmtBytes(t.done)} sent"
            }
            Text(line, style = MaterialTheme.typography.bodySmall)
            if (t.total > 0) {
                LinearProgressIndicator(
                    progress = { (t.done.toFloat() / t.total.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            TextButton(onClick = onCancel) { Text("Cancel transfer") }
        } else {
            Text("${t.label}: ${t.message}", style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = onDismiss) { Text("Dismiss") }
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun InstallTab(host: String) {
    val scope = rememberCoroutineScope()
    var port by rememberPref("install_port", "12800") // etaHEN installer service port
    var pkgUrl by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Idle") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Field("Installer port (etaHEN: 12800)", port) { port = it }
        Field("Package URL", pkgUrl) { pkgUrl = it }
        Button(
            enabled = host.isNotBlank() && pkgUrl.isNotBlank(),
            onClick = {
                status = "Sending…"
                scope.launch { status = sendInstall(host.trim(), port.trim(), pkgUrl.trim()) }
            }
        ) { Text("Send") }
        Text(status)
    }
}

@Composable
fun PayloadTab(host: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var port by rememberPref("payload_port", "9021") // common ELF-loader port; check your loader
    var uri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Idle") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri = it }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Field("Loader port", port) { port = it }
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Choose payload (.elf / .bin)") }
        Text(uri?.let { ctx.contentResolver.displayName(it) } ?: "No file chosen")
        Button(
            enabled = host.isNotBlank() && uri != null && port.toIntOrNull() != null,
            onClick = {
                status = "Sending…"
                scope.launch { status = sendPayload(ctx.contentResolver, uri!!, host.trim(), port.toInt()) }
            }
        ) { Text("Send payload") }
        Text(status)
    }
}

@Composable
fun UploadTab(host: String, pass: String, onPassChange: (String) -> Unit, onStart: (TransferRequest) -> Unit) {
    val ctx = LocalContext.current
    var port by rememberPref("ftp_port", "2121") // common console FTP port; check your FTP server
    var user by rememberPref("ftp_user", "anonymous")
    var dir by rememberPref("ftp_dir", "/data")
    var uri by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri = it }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Field("FTP port", port) { port = it }
        Field("Username", user) { user = it }
        Field("Password", pass, onPassChange)
        Field("Remote folder", dir) { dir = it }
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Choose file") }
        Text(uri?.let { ctx.contentResolver.displayName(it) } ?: "No file chosen")
        Button(
            enabled = host.isNotBlank() && uri != null && port.trim().toIntOrNull() != null,
            onClick = {
                uri?.let { u ->
                    onStart(
                        TransferRequest(
                            name = ctx.contentResolver.displayName(u),
                            host = host.trim(),
                            port = port.trim().toInt(),
                            user = user.trim(),
                            pass = pass,
                            dir = dir.trim(),
                            fileUri = u.toString()
                        )
                    )
                }
            }
        ) { Text("Upload in background") }
        Text(
            "Progress shows under the tabs and in a notification. It keeps going if you leave the app.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun WebTab(web: WebView, homeUrl: String, onHomeChange: (String) -> Unit, modifier: Modifier = Modifier) {
    var edit by remember(homeUrl) { mutableStateOf(homeUrl) }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { web.loadUrl(homeUrl) }) { Text("Home") }
            Button(onClick = { web.reload() }) { Text("Reload") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = edit, onValueChange = { edit = it },
                label = { Text("Homepage URL") }, singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                val url = normalizeUrl(edit)
                onHomeChange(url)
                web.loadUrl(url)
            }) { Text("Set") }
        }
        AndroidView(factory = { web }, modifier = Modifier.fillMaxWidth().weight(1f))
    }
}
