package com.example.pssender // change to match your project's package name

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.View
import android.webkit.CookieManager
import android.webkit.URLUtil
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val TAB_FILES = 3
private const val TAB_WEB = 4

/** How often the console card rechecks the console while the app is on screen. */
private const val CHECK_EVERY_MS = 6000L

/** How long the result of a successful transfer stays above the bottom bar before it hides itself. */
private const val RESULT_VISIBLE_MS = 15000L

/** A transfer that ended longer ago than this no longer buzzes (for example when you open the app much later). */
private const val BUZZ_WINDOW_MS = 3000L

/** The five screens, in the order of the bottom bar. The position is the tab number used below. */
private val NAV_ITEMS = listOf(
    NavItem(R.string.nav_install, InstallIcon),
    NavItem(R.string.nav_payload, PayloadIcon),
    NavItem(R.string.nav_upload, UploadIcon),
    NavItem(R.string.nav_files, FilesIcon),
    NavItem(R.string.nav_web, WebIcon)
)

class MainActivity : ComponentActivity() {
    /** A link another app shared to us; the screen consumes it and sets it back to null. */
    private var sharedLink by mutableStateOf<String?>(null)

    /**
     * True while the app is on screen. The console is only checked then, so nothing runs in the background.
     * A plain flag on purpose: the screen stops drawing while the app is hidden, so it reads this directly.
     */
    private var onScreen = false

    /** Goes up each time the app comes on screen, which makes the screen start its console checks again. */
    private var timesShown by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Only on a fresh start: after a rotation the same intent would otherwise be handled twice
        if (savedInstanceState == null) readShare(intent)
        setContent { SenderApp(sharedLink, { sharedLink = null }, timesShown) { onScreen } }
    }

    override fun onStart() {
        super.onStart()
        onScreen = true
        timesShown++
    }

    override fun onStop() {
        onScreen = false
        super.onStop()
    }

    // The app is already open when something is shared to it
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readShare(intent)
    }

    private fun readShare(source: Intent?) {
        val i = source ?: return
        if (i.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        sharedLink = Regex("""https?://\S+""").find(text)?.value
    }
}

/** A text setting that is loaded from, and saved to, SharedPreferences whenever it changes. */
@Composable
fun rememberPref(key: String, default: String): MutableState<String> {
    val prefs = LocalContext.current.getSharedPreferences("settings", Context.MODE_PRIVATE)
    val state = remember { mutableStateOf(prefs.getString(key, default) ?: default) }
    LaunchedEffect(state.value) { prefs.edit().putString(key, state.value).apply() }
    return state
}

/** Reads a saved setting without composing, for use inside button handlers. */
fun readPref(ctx: Context, key: String, default: String): String =
    ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).getString(key, default) ?: default

/** A short vibration when a transfer ends: a "confirm" tick for success and a "reject" buzz for a failure. */
private fun buzz(view: View, ok: Boolean) {
    val kind = when {
        Build.VERSION.SDK_INT < 30 -> HapticFeedbackConstants.LONG_PRESS
        ok -> HapticFeedbackConstants.CONFIRM
        else -> HapticFeedbackConstants.REJECT
    }
    view.performHapticFeedback(kind)
}

/**
 * The whole app screen. [timesShown] changes every time the app comes back on screen (so the console checks restart),
 * and [isShown] tells right now whether it is on screen (so they stop when it is hidden).
 */
@Composable
fun SenderApp(
    sharedLink: String? = null,
    onSharedConsumed: () -> Unit = {},
    timesShown: Int = 1,
    isShown: () -> Boolean = { true }
) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    var profiles by remember { mutableStateOf(ProfileStore.load(ctx)) }
    var activeId by remember { mutableStateOf(ProfileStore.activeId(ctx, profiles)) }
    var passwords by remember { mutableStateOf(mapOf<String, String>()) } // FTP passwords: not saved, kept for this session only
    var homeUrl by rememberPref("home_url_v2", DEFAULT_HOME)
    var tab by remember { mutableStateOf(0) }
    var webCanGoBack by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<PendingDownload?>(null) }
    var offSiteUrl by remember { mutableStateOf<String?>(null) }
    var statusLine by remember { mutableStateOf("") }
    var showConsoles by remember { mutableStateOf(false) }
    var showAddress by remember { mutableStateOf(false) }
    var shelfVersion by remember { mutableStateOf(0) }
    var transferConsole by remember { mutableStateOf("") } // name of the console the running transfer was started for
    var consoleStatus by remember { mutableStateOf<ConsoleStatus?>(null) }
    var wasActive by remember { mutableStateOf(false) }
    val files = remember { FilesModel() }
    val transfer by TransferState.info.collectAsState()
    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    // One WebView for the whole session, so the page survives switching tabs.
    val webView = remember {
        allowedSites.add(siteOf(Uri.parse(homeUrl).host))
        buildWebView(ctx, homeUrl, { webCanGoBack = it }, { offSiteUrl = it }) { pending = it }
    }

    // The selected console. Everything below reads its IP, ports and FTP login from here.
    val active = profiles.firstOrNull { it.id == activeId } ?: profiles.first()
    val host = active.host
    val ftpPass = passwords[active.id] ?: ""
    val setFtpPass: (String) -> Unit = { passwords = passwords + (activeId to it) }
    val updateActive: ((Profile) -> Profile) -> Unit = { change ->
        profiles = profiles.map { if (it.id == activeId) change(it) else it }
        ProfileStore.save(ctx, profiles)
    }
    val ftpSettings: FtpSettings? = active.ftpPort.trim().toIntOrNull()?.let { port ->
        if (active.host.isBlank()) null else FtpSettings(active.host.trim(), port, active.ftpUser.trim(), ftpPass)
    }
    val switchConsole: (String) -> Unit = { id ->
        if (id != activeId) {
            activeId = id
            ProfileStore.saveActive(ctx, id)
            statusLine = ""
            files.reset()
        }
    }

    // What the console card checks: the three services of the selected console
    val installerName = str(R.string.service_installer)
    val loaderName = str(R.string.service_loader)
    val ftpName = str(R.string.service_ftp)
    val target = ConsoleTarget(
        host.trim(),
        listOf(
            installerName to active.installPort.trim().toIntOrNull(),
            loaderName to active.payloadPort.trim().toIntOrNull(),
            ftpName to active.ftpPort.trim().toIntOrNull()
        )
    )
    val level = consoleLevel(target, consoleStatus)
    val checks = consoleStatus?.takeIf { it.target == target }?.checks ?: pendingChecks(target)

    // Checks the console now and then, but only while the app is on screen and an address is set. The loop ends
    // by itself soon after the app is hidden, and a new one starts when it comes back (timesShown changes).
    LaunchedEffect(target, timesShown) {
        if (target.host.isEmpty()) return@LaunchedEffect
        delay(300) // typing an address or a port shouldn't start a check for every key
        while (isShown()) {
            // Not while a transfer runs: the console is busy with it, and the transfer card shows how it goes
            if (!TransferState.info.value.active) consoleStatus = checkConsole(target)
            delay(CHECK_EVERY_MS)
        }
    }

    // A short buzz when a transfer ends while you are looking at the app (not when you come back long after)
    LaunchedEffect(transfer.active) {
        val justEnded = System.currentTimeMillis() - transfer.endedAt < BUZZ_WINDOW_MS
        if (wasActive && !transfer.active && transfer.label.isNotEmpty() && justEnded && isShown()) buzz(view, transfer.ok)
        wasActive = transfer.active
    }

    // A finished transfer that worked hides itself after a while on screen; a failed one stays until dismissed
    LaunchedEffect(transfer.active, transfer.ok, transfer.label, timesShown) {
        if (!transfer.active && transfer.ok && transfer.label.isNotEmpty() && isShown()) {
            delay(RESULT_VISIBLE_MS)
            if (isShown()) TransferState.clear()
        }
    }

    // A link shared from another app goes through the same chooser as a download from the Web tab
    LaunchedEffect(sharedLink) {
        if (sharedLink != null) {
            pending = PendingDownload(sharedLink, FALLBACK_UA, null, null)
            onSharedConsumed()
        }
    }

    // Starts a background FTP transfer (one at a time) and asks for notification permission the first time
    val startTransfer: (TransferRequest) -> Unit = { req ->
        if (TransferState.info.value.active) {
            statusLine = AppText.get(R.string.msg_transfer_running)
        } else {
            if (Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            statusLine = ""
            transferConsole = active.name
            TransferService.start(ctx, req)
        }
    }

    BackHandler(enabled = tab == TAB_WEB && webCanGoBack) { webView.goBack() }

    AppTheme(active.color) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(modifier = Modifier.fillMaxSize()) {
                AppHeader(active.name, accentColor(active.color)) { showConsoles = true }
                ConsoleCard(
                    host = host.trim(),
                    level = level,
                    checks = checks,
                    compact = tab == TAB_FILES || tab == TAB_WEB, // these two need the room
                    onEdit = { showAddress = true },
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Column(
                    modifier = Modifier.weight(1f).padding(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (tab) {
                        TAB_FILES -> FilesTab(
                            model = files,
                            scope = scope,
                            settings = ftpSettings,
                            profile = active,
                            pass = ftpPass,
                            onPassChange = setFtpPass,
                            onUpdateProfile = updateActive,
                            transferActive = transfer.active,
                            onStart = startTransfer,
                            modifier = Modifier.weight(1f)
                        )
                        TAB_WEB -> WebTab(
                            webView, homeUrl,
                            { allowedSites.add(siteOf(Uri.parse(it).host)); homeUrl = it },
                            Modifier.weight(1f)
                        )
                        else -> {
                            // The form tabs scroll, so nothing is cut off on small screens
                            Column(
                                modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                when (tab) {
                                    0 -> InstallTab(host, active.installPort) { v -> updateActive { it.copy(installPort = v) } }
                                    1 -> PayloadTab(host, active.payloadPort, { v -> updateActive { it.copy(payloadPort = v) } }, shelfVersion)
                                    else -> UploadTab(host, active, updateActive, ftpPass, setFtpPass, startTransfer)
                                }
                            }
                        }
                    }
                }
                if (statusLine.isNotEmpty()) {
                    StatusStrip(statusLine) { statusLine = "" }
                }
                TransferCard(
                    transfer, transferConsole,
                    onCancel = { TransferState.requestCancel() },
                    onDismiss = { TransferState.clear() }
                )
                BottomBar(NAV_ITEMS, tab) { tab = it }
            }

            if (showConsoles) {
                ConsolesDialog(
                    profiles = profiles,
                    activeId = active.id,
                    onSwitch = switchConsole,
                    onAdd = {
                        val p = newProfile(profiles)
                        profiles = profiles + p
                        ProfileStore.save(ctx, profiles)
                        switchConsole(p.id)
                        showConsoles = false
                    },
                    onRename = { name -> updateActive { it.copy(name = name) } },
                    onDelete = {
                        val remaining = profiles.filter { it.id != activeId }
                        if (remaining.isNotEmpty()) {
                            profiles = remaining
                            ProfileStore.save(ctx, remaining)
                            switchConsole(remaining.first().id)
                        }
                    },
                    onColor = { c -> updateActive { it.copy(color = c) } },
                    onLanguage = { openLanguageSettings(ctx) },
                    onClose = { showConsoles = false }
                )
            }

            if (showAddress) {
                ConsoleEditDialog(
                    host = host,
                    onHostChange = { v -> updateActive { it.copy(host = v) } },
                    onClose = { showAddress = false }
                )
            }

            offSiteUrl?.let { u ->
                val site = siteOf(Uri.parse(u).host)
                AlertDialog(
                    onDismissRequest = { offSiteUrl = null },
                    title = { Text(str(R.string.offsite_title)) },
                    text = { Text(str(R.string.offsite_text, site)) },
                    confirmButton = {
                        TextButton(onClick = {
                            allowedSites.add(site)
                            offSiteUrl = null
                            webView.loadUrl(u)
                        }) { Text(str(R.string.action_open)) }
                    },
                    dismissButton = { TextButton(onClick = { offSiteUrl = null }) { Text(str(R.string.action_block)) } }
                )
            }

            pending?.let { d ->
                val name = URLUtil.guessFileName(d.url, d.contentDisposition, d.mimeType)

                AlertDialog(
                    onDismissRequest = { pending = null },
                    title = { Text(name) },
                    text = {
                        Column(
                            modifier = Modifier.verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    pending = null
                                    if (host.isBlank()) {
                                        statusLine = AppText.get(R.string.msg_set_ip_first)
                                    } else {
                                        statusLine = AppText.get(R.string.msg_sending_link)
                                        scope.launch {
                                            statusLine = sendInstall(host.trim(), active.installPort.trim(), d.url)
                                        }
                                    }
                                }
                            ) { Text(str(R.string.choose_install)) }
                            Button(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    pending = null
                                    val port = active.ftpPort.trim().toIntOrNull()
                                    if (host.isBlank() || port == null) {
                                        statusLine = AppText.get(R.string.msg_check_ip_ftp)
                                    } else {
                                        startTransfer(
                                            TransferRequest(
                                                name = name,
                                                host = host.trim(),
                                                port = port,
                                                user = active.ftpUser.trim(),
                                                pass = ftpPass,
                                                dir = active.ftpDir.trim(),
                                                url = d.url,
                                                userAgent = d.userAgent,
                                                cookie = CookieManager.getInstance().getCookie(d.url)
                                            )
                                        )
                                    }
                                }
                            ) { Text(str(R.string.choose_ftp)) }
                            Button(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    pending = null
                                    statusLine = AppText.get(R.string.msg_adding_to_shelf_link)
                                    val cookie = CookieManager.getInstance().getCookie(d.url)
                                    scope.launch {
                                        statusLine = shelfAddFromUrl(ctx, d.url, d.userAgent, cookie, name)
                                        shelfVersion++
                                    }
                                }
                            ) { Text(str(R.string.choose_shelf)) }
                            Button(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    pending = null
                                    saveToPhone(ctx, d)
                                }
                            ) { Text(str(R.string.choose_phone)) }
                            Text(str(R.string.choose_help, fmtBytes(SHELF_MAX_BYTES)), style = MaterialTheme.typography.bodySmall)
                        }
                    },
                    confirmButton = {},
                    dismissButton = { TextButton(onClick = { pending = null }) { Text(str(R.string.action_cancel)) } }
                )
            }
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun InstallTab(host: String, port: String, onPortChange: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var pkgUrl by remember { mutableStateOf("") }
    val idle = str(R.string.status_idle)
    var status by remember { mutableStateOf(idle) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Field(str(R.string.install_port_label), port, onPortChange) // etaHEN installer service port
        Field(str(R.string.install_url_label), pkgUrl) { pkgUrl = it }
        Button(
            enabled = host.isNotBlank() && pkgUrl.isNotBlank(),
            onClick = {
                status = AppText.get(R.string.status_sending)
                scope.launch { status = sendInstall(host.trim(), port.trim(), pkgUrl.trim()) }
            }
        ) { Text(str(R.string.action_send)) }
        Text(status)
    }
}

@Composable
fun UploadTab(
    host: String,
    profile: Profile,
    update: ((Profile) -> Profile) -> Unit,
    pass: String,
    onPassChange: (String) -> Unit,
    onStart: (TransferRequest) -> Unit
) {
    val ctx = LocalContext.current
    var uri by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri = it }
    val port = profile.ftpPort.trim().toIntOrNull()

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FtpSettingsFields(profile, update, pass, onPassChange)
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text(str(R.string.upload_choose)) }
        Text(uri?.let { ctx.contentResolver.displayName(it) } ?: str(R.string.upload_none))
        Button(
            enabled = host.isNotBlank() && uri != null && port != null,
            onClick = {
                val u = uri
                if (u != null && port != null) {
                    onStart(
                        TransferRequest(
                            name = ctx.contentResolver.displayName(u),
                            host = host.trim(),
                            port = port,
                            user = profile.ftpUser.trim(),
                            pass = pass,
                            dir = profile.ftpDir.trim(),
                            fileUri = u.toString()
                        )
                    )
                }
            }
        ) { Text(str(R.string.upload_start)) }
        Text(str(R.string.upload_help), style = MaterialTheme.typography.bodySmall)
    }
}
