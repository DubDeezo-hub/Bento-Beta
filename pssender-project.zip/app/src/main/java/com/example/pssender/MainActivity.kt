package com.example.pssender // change to match your project's package name

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch

/** Starting homepage for the Web tab. It can be changed inside the app. */
const val DEFAULT_HOME = "https://www.superpsx.com/category/ps5/ps5-games/"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { SenderApp() } }
    }
}

/** A text setting that is loaded from, and saved to, SharedPreferences whenever it changes. */
@Composable
fun rememberPref(key: String, default: String): MutableState<String> {
    val prefs = LocalContext.current.getSharedPreferences("settings", Context.MODE_PRIVATE)
    val state = remember { mutableStateOf(prefs.getString(key, default) ?: default) }
    LaunchedEffect(state.value) { prefs.edit().putString(key, state.value).apply() }
    return state
}

fun normalizeUrl(input: String): String {
    val t = input.trim()
    return if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
}

@SuppressLint("SetJavaScriptEnabled")
fun buildWebView(ctx: Context, startUrl: String, onCanGoBack: (Boolean) -> Unit): WebView =
    WebView(ctx).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        webViewClient = object : WebViewClient() {
            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                onCanGoBack(view?.canGoBack() == true)
            }
        }
        // WebView doesn't download files by itself, so hand them to the system download manager.
        setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            val req = DownloadManager.Request(Uri.parse(url))
                .setMimeType(mimeType)
                .addRequestHeader("User-Agent", userAgent)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(url, contentDisposition, mimeType)
                )
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            Toast.makeText(ctx, "Download started (see Downloads)", Toast.LENGTH_SHORT).show()
        }
        loadUrl(startUrl)
    }

@Composable
fun SenderApp() {
    val ctx = LocalContext.current
    var host by rememberPref("host", "")
    var homeUrl by rememberPref("home_url_v2", DEFAULT_HOME)
    var tab by remember { mutableStateOf(0) }
    var webCanGoBack by remember { mutableStateOf(false) }
    // One WebView for the whole session, so the page survives switching tabs.
    val webView = remember { buildWebView(ctx, homeUrl) { webCanGoBack = it } }
    val tabs = listOf("Install", "Payload", "Upload", "Web")

    BackHandler(enabled = tab == 3 && webCanGoBack) { webView.goBack() }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("PS5 Sender", style = MaterialTheme.typography.headlineSmall)
        if (tab != 3) Field("Console IP", host) { host = it }
        TabRow(selectedTabIndex = tab) {
            tabs.forEachIndexed { i, title ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
            }
        }
        when (tab) {
            0 -> InstallTab(host)
            1 -> PayloadTab(host)
            2 -> UploadTab(host)
            else -> WebTab(webView, homeUrl, { homeUrl = it }, Modifier.weight(1f))
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun InstallTab(host: String) {
    val scope = rememberCoroutineScope()
    var port by rememberPref("install_port", "12800") // etaHEN installer service port
    var pkgUrl by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Idle") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Field("Installer port (etaHEN: 12800)", port) { port = it }
        Field("Package URL", pkgUrl) { pkgUrl = it }
        Button(
            enabled = host.isNotBlank() && pkgUrl.isNotBlank(),
            onClick = {
                status = "Sending…"
                scope.launch { status = sendInstall(host.trim(), port.trim(), pkgUrl.trim()) }
            }
        ) { Text("Send") }
        Text(status)
    }
}

@Composable
fun PayloadTab(host: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var port by rememberPref("payload_port", "9021") // common ELF-loader port; check your loader
    var uri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Idle") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri = it }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Field("Loader port", port) { port = it }
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Choose payload (.elf / .bin)") }
        Text(uri?.let { ctx.contentResolver.displayName(it) } ?: "No file chosen")
        Button(
            enabled = host.isNotBlank() && uri != null && port.toIntOrNull() != null,
            onClick = {
                status = "Sending…"
                scope.launch { status = sendPayload(ctx.contentResolver, uri!!, host.trim(), port.toInt()) }
            }
        ) { Text("Send payload") }
        Text(status)
    }
}

@Composable
fun UploadTab(host: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var port by rememberPref("ftp_port", "2121") // common console FTP port; check your FTP server
    var user by rememberPref("ftp_user", "anonymous")
    var pass by remember { mutableStateOf("") } // not saved
    var dir by rememberPref("ftp_dir", "/data")
    var uri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Idle") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri = it }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Field("FTP port", port) { port = it }
        Field("Username", user) { user = it }
        Field("Password", pass) { pass = it }
        Field("Remote folder", dir) { dir = it }
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Choose file") }
        Text(uri?.let { ctx.contentResolver.displayName(it) } ?: "No file chosen")
        Button(
            enabled = host.isNotBlank() && uri != null && port.toIntOrNull() != null,
            onClick = {
                status = "Uploading…"
                scope.launch {
                    status = ftpUpload(
                        ctx.contentResolver, uri!!, host.trim(), port.toInt(),
                        user.trim(), pass, dir.trim()
                    )
                }
            }
        ) { Text("Upload") }
        Text(status)
    }
}

@Composable
fun WebTab(web: WebView, homeUrl: String, onHomeChange: (String) -> Unit, modifier: Modifier = Modifier) {
    var edit by remember(homeUrl) { mutableStateOf(homeUrl) }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { web.loadUrl(homeUrl) }) { Text("Home") }
            Button(onClick = { web.reload() }) { Text("Reload") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = edit, onValueChange = { edit = it },
                label = { Text("Homepage URL") }, singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                val url = normalizeUrl(edit)
                onHomeChange(url)
                web.loadUrl(url)
            }) { Text("Set") }
        }
        AndroidView(factory = { web }, modifier = Modifier.fillMaxWidth().weight(1f))
    }
}
