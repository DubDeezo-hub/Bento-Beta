package com.example.pssender // change to match your project's package name

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.URLUtil
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private const val TAB_FILES = 3
private const val TAB_WEB = 4

class MainActivity : ComponentActivity() {
    /** A link another app shared to us; the screen consumes it and sets it back to null. */
    private var sharedLink by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Only on a fresh start: after a rotation the same intent would otherwise be handled twice
        if (savedInstanceState == null) readShare(intent)
        setContent { MaterialTheme { SenderApp(sharedLink) { sharedLink = null } } }
    }

    // The app is already open when something is shared to it
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readShare(intent)
    }

    private fun readShare(source: Intent?) {
        val i = source ?: return
        if (i.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        sharedLink = Regex("""https?://\S+""").find(text)?.value
    }
}

/** A text setting that is loaded from, and saved to, SharedPreferences whenever it changes. */
@Composable
fun rememberPref(key: String, default: String): MutableState<String> {
    val prefs = LocalContext.current.getSharedPreferences("settings", Context.MODE_PRIVATE)
    val state = remember { mutableStateOf(prefs.getString(key, default) ?: default) }
    LaunchedEffect(state.value) { prefs.edit().putString(key, state.value).apply() }
    return state
}

/** Reads a saved setting without composing, for use inside button handlers. */
fun readPref(ctx: Context, key: String, default: String): String =
    ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).getString(key, default) ?: default

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SenderApp(sharedLink: String? = null, onSharedConsumed: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var profiles by remember { mutableStateOf(ProfileStore.load(ctx)) }
    var activeId by remember { mutableStateOf(ProfileStore.activeId(ctx, profiles)) }
    var passwords by remember { mutableStateOf(mapOf<String, String>()) } // FTP passwords: not saved, kept for this session only
    var homeUrl by rememberPref("home_url_v2", DEFAULT_HOME)
    var tab by remember { mutableStateOf(0) }
    var webCanGoBack by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<PendingDownload?>(null) }
    var offSiteUrl by remember { mutableStateOf<String?>(null) }
    var statusLine by remember { mutableStateOf("") }
    var testResult by remember { mutableStateOf("") }
    var showConsoles by remember { mutableStateOf(false) }
    var shelfVersion by remember { mutableStateOf(0) }
    val files = remember { FilesModel() }
    val transfer by TransferState.info.collectAsState()
    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    // One WebView for the whole session, so the page survives switching tabs.
    val webView = remember {
        allowedSites.add(siteOf(Uri.parse(homeUrl).host))
        buildWebView(ctx, homeUrl, { webCanGoBack = it }, { offSiteUrl = it }) { pending = it }
    }
    val tabs = listOf("Install", "Payload", "Upload", "Files", "Web")

    // The selected console. Everything below reads its IP, ports and FTP login from here.
    val active = profiles.firstOrNull { it.id == activeId } ?: profiles.first()
    val host = active.host
    val ftpPass = passwords[active.id] ?: ""
    val setFtpPass: (String) -> Unit = { passwords = passwords + (activeId to it) }
    val updateActive: ((Profile) -> Profile) -> Unit = { change ->
        profiles = profiles.map { if (it.id == activeId) change(it) else it }
        ProfileStore.save(ctx, profiles)
    }
    val ftpSettings: FtpSettings? = active.ftpPort.trim().toIntOrNull()?.let { port ->
        if (active.host.isBlank()) null else FtpSettings(active.host.trim(), port, active.ftpUser.trim(), ftpPass)
    }
    val switchConsole: (String) -> Unit = { id ->
        if (id != activeId) {
            activeId = id
            ProfileStore.saveActive(ctx, id)
            testResult = ""
            statusLine = ""
            files.reset()
        }
    }

    // A link shared from another app goes through the same chooser as a download from the Web tab
    LaunchedEffect(sharedLink) {
        if (sharedLink != null) {
            pending = PendingDownload(sharedLink, FALLBACK_UA, null, null)
            onSharedConsumed()
        }
    }

    // Starts a background FTP transfer (one at a time) and asks for notification permission the first time
    val startTransfer: (TransferRequest) -> Unit = { req ->
        if (TransferState.info.value.active) {
            statusLine = "A transfer is already running. Wait for it to finish or cancel it first."
        } else {
            if (Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            statusLine = ""
            TransferService.start(ctx, req)
        }
    }

    BackHandler(enabled = tab == TAB_WEB && webCanGoBack) { webView.goBack() }

    if (showConsoles) {
        ConsolesDialog(
            profiles = profiles,
            activeId = active.id,
            onSwitch = switchConsole,
            onAdd = {
                val p = newProfile(profiles)
                profiles = profiles + p
                ProfileStore.save(ctx, profiles)
                switchConsole(p.id)
                showConsoles = false
            },
            onRename = { name -> updateActive { it.copy(name = name) } },
            onDelete = {
                val remaining = profiles.filter { it.id != activeId }
                if (remaining.isNotEmpty()) {
                    profiles = remaining
                    ProfileStore.save(ctx, remaining)
                    switchConsole(remaining.first().id)
                }
            },
            onClose = { showConsoles = false }
        )
    }

    offSiteUrl?.let { u ->
        val site = siteOf(Uri.parse(u).host)
        AlertDialog(
            onDismissRequest = { offSiteUrl = null },
            title = { Text("Leave this site?") },
            text = {
                Text(
                    "The page wants to open $site. Ads often trigger this when you tap a link, " +
                        "so only continue if you expected it."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    allowedSites.add(site)
                    offSiteUrl = null
                    webView.loadUrl(u)
                }) { Text("Open") }
            },
            dismissButton = { TextButton(onClick = { offSiteUrl = null }) { Text("Block") } }
        )
    }

    pending?.let { d ->
        val name = URLUtil.guessFileName(d.url, d.contentDisposition, d.mimeType)

        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text(name) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            pending = null
                            if (host.isBlank()) {
                                statusLine = "Enter the Console IP first."
                            } else {
                                statusLine = "Sending link to PS5…"
                                scope.launch {
                                    statusLine = sendInstall(host.trim(), active.installPort.trim(), d.url)
                                }
                            }
                        }
                    ) { Text("Send link to PS5 installer") }
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            pending = null
                            val port = active.ftpPort.trim().toIntOrNull()
                            if (host.isBlank() || port == null) {
                                statusLine = "Check the Console IP and FTP port."
                            } else {
                                startTransfer(
                                    TransferRequest(
                                        name = name,
                                        host = host.trim(),
                                        port = port,
                                        user = active.ftpUser.trim(),
                                        pass = ftpPass,
                                        dir = active.ftpDir.trim(),
                                        url = d.url,
                                        userAgent = d.userAgent,
                                        cookie = CookieManager.getInstance().getCookie(d.url)
                                    )
                                )
                            }
                        }
                    ) { Text("Upload to PS5 (FTP)") }
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            pending = null
                            statusLine = "Adding to the payload shelf…"
                            val cookie = CookieManager.getInstance().getCookie(d.url)
                            scope.launch {
                                statusLine = shelfAddFromUrl(ctx, d.url, d.userAgent, cookie, name)
                                shelfVersion++
                            }
                        }
                    ) { Text("Save to payload shelf") }
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            pending = null
                            saveToPhone(ctx, d)
                        }
                    ) { Text("Save to phone") }
                    Text(
                        "The installer needs a direct package link the console can open without logging in. " +
                            "FTP works for any file and keeps your login session. The phone relays the data " +
                            "in the background, with progress under the tabs and in a notification. " +
                            "The payload shelf keeps a small payload (up to 64 MB) inside the app for the Payload tab.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancel") } }
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("PS5 Sender", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            TextButton(onClick = { showConsoles = true }) {
                Text("${active.name} ▾", maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Field("Console IP", host) { v -> updateActive { it.copy(host = v) } }
        if (tab != TAB_WEB) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Button(
                    enabled = host.isNotBlank(),
                    onClick = {
                        testResult = "Testing…"
                        scope.launch {
                            testResult = testConnection(
                                host.trim(),
                                listOf(
                                    "Installer" to active.installPort.trim().toIntOrNull(),
                                    "Loader" to active.payloadPort.trim().toIntOrNull(),
                                    "FTP" to active.ftpPort.trim().toIntOrNull()
                                )
                            )
                        }
                    }
                ) { Text("Test connection") }
                if (testResult.isNotEmpty()) {
                    Text(testResult, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 0.dp) {
            tabs.forEachIndexed { i, title ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
            }
        }
        if (statusLine.isNotEmpty()) {
            Text(statusLine, style = MaterialTheme.typography.bodySmall)
        }
        TransferBar(transfer, onCancel = { TransferState.requestCancel() }, onDismiss = { TransferState.clear() })
        when (tab) {
            TAB_FILES -> FilesTab(
                model = files,
                scope = scope,
                settings = ftpSettings,
                profile = active,
                pass = ftpPass,
                onPassChange = setFtpPass,
                onUpdateProfile = updateActive,
                transferActive = transfer.active,
                onStart = startTransfer,
                modifier = Modifier.weight(1f)
            )
            TAB_WEB -> WebTab(
                webView, homeUrl,
                { allowedSites.add(siteOf(Uri.parse(it).host)); homeUrl = it },
                Modifier.weight(1f)
            )
            else -> {
                // The form tabs scroll, so nothing is cut off on small screens
                Column(
                    modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (tab) {
                        0 -> InstallTab(host, active.installPort) { v -> updateActive { it.copy(installPort = v) } }
                        1 -> PayloadTab(host, active.payloadPort, { v -> updateActive { it.copy(payloadPort = v) } }, shelfVersion)
                        else -> UploadTab(host, active, updateActive, ftpPass, setFtpPass, startTransfer)
                    }
                }
            }
        }
    }
}

/** Progress of the current background transfer, with Cancel while it runs and Dismiss once it's done. */
@Composable
fun TransferBar(t: TransferInfo, onCancel: () -> Unit, onDismiss: () -> Unit) {
    if (t.label.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (t.active) {
            val line = if (t.total > 0) {
                "${t.label}: ${t.done * 100 / t.total}% (${fmtBytes(t.done)} of ${fmtBytes(t.total)})"
            } else {
                "${t.label}: ${fmtBytes(t.done)} ${if (t.download) "received" else "sent"}"
            }
            Text(line, style = MaterialTheme.typography.bodySmall)
            if (t.total > 0) {
                LinearProgressIndicator(
                    progress = { (t.done.toFloat() / t.total.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            TextButton(onClick = onCancel) { Text("Cancel transfer") }
        } else {
            Text("${t.label}: ${t.message}", style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = onDismiss) { Text("Dismiss") }
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun InstallTab(host: String, port: String, onPortChange: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var pkgUrl by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Idle") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Field("Installer port (etaHEN: 12800)", port, onPortChange) // etaHEN installer service port
        Field("Package URL", pkgUrl) { pkgUrl = it }
        Button(
            enabled = host.isNotBlank() && pkgUrl.isNotBlank(),
            onClick = {
                status = "Sending…"
                scope.launch { status = sendInstall(host.trim(), port.trim(), pkgUrl.trim()) }
            }
        ) { Text("Send") }
        Text(status)
    }
}

@Composable
fun UploadTab(
    host: String,
    profile: Profile,
    update: ((Profile) -> Profile) -> Unit,
    pass: String,
    onPassChange: (String) -> Unit,
    onStart: (TransferRequest) -> Unit
) {
    val ctx = LocalContext.current
    var uri by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri = it }
    val port = profile.ftpPort.trim().toIntOrNull()

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FtpSettingsFields(profile, update, pass, onPassChange)
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Choose file") }
        Text(uri?.let { ctx.contentResolver.displayName(it) } ?: "No file chosen")
        Button(
            enabled = host.isNotBlank() && uri != null && port != null,
            onClick = {
                val u = uri
                if (u != null && port != null) {
                    onStart(
                        TransferRequest(
                            name = ctx.contentResolver.displayName(u),
                            host = host.trim(),
                            port = port,
                            user = profile.ftpUser.trim(),
                            pass = pass,
                            dir = profile.ftpDir.trim(),
                            fileUri = u.toString()
                        )
                    )
                }
            }
        ) { Text("Upload in background") }
        Text(
            "Progress shows under the tabs and in a notification. It keeps going if you leave the app.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
