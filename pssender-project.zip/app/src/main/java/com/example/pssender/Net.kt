package com.example.pssender // change to match your project's package name

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

private val http = OkHttpClient.Builder()
    .connectTimeout(5, TimeUnit.SECONDS)
    .readTimeout(10, TimeUnit.SECONDS)
    .build()

/** Display name of a file picked through the system file picker. */
fun ContentResolver.displayName(uri: Uri): String =
    query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: "file"

/**
 * Asks the console's package-installer service (port 12800 on etaHEN) to install a package from a URL.
 * 1) etaHEN style: multipart POST /upload with a "url" field; success text contains "SUCCESS:".
 * 2) Remote Package Installer style: POST /api/install with {"type":"direct","packages":[...]}.
 * Formats are taken from public documentation of existing installer tools; verify against your console.
 */
suspend fun sendInstall(host: String, port: String, pkgUrl: String): String =
    withContext(Dispatchers.IO) {
        val base = "http://$host:$port"
        try {
            val form = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("file", "", "".toRequestBody("application/octet-stream".toMediaType()))
                .addFormDataPart("url", pkgUrl)
                .build()
            val first = http.newCall(Request.Builder().url("$base/upload").post(form).build())
                .execute().use { it.code to it.body?.string().orEmpty() }
            if (first.second.contains("SUCCESS:")) {
                return@withContext "Installer accepted it: ${first.second.trim()}"
            }

            // RPI-style: URL-encoded, with the https scheme swapped to http
            val encoded = URLEncoder.encode(pkgUrl, "UTF-8").replace("https%3A", "http%3A")
            val json = JSONObject().put("type", "direct").put("packages", JSONArray().put(encoded)).toString()
            val second = http.newCall(
                Request.Builder().url("$base/api/install")
                    .post(json.toRequestBody("text/plain; charset=utf-8".toMediaType())).build()
            ).execute().use { it.code to it.body?.string().orEmpty() }
            if (second.second.contains("success")) {
                "Installer accepted it: ${second.second.trim()}"
            } else {
                "Not accepted (upload ${first.first}: ${first.second.take(80)}; api ${second.first}: ${second.second.take(80)})"
            }
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
    }

/**
 * Sends a file's raw bytes over TCP to a payload/ELF loader already listening on the console,
 * then closes the write side so the loader sees end-of-file.
 */
suspend fun sendPayload(cr: ContentResolver, uri: Uri, host: String, port: Int): String =
    withContext(Dispatchers.IO) {
        val input = cr.openInputStream(uri) ?: return@withContext "Could not open file"
        try {
            input.use { ins ->
                Socket().use { sock ->
                    sock.connect(InetSocketAddress(host, port), 5000)
                    val out = sock.getOutputStream()
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        total += n
                    }
                    out.flush()
                    sock.shutdownOutput()
                    "Sent $total bytes"
                }
            }
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
    }

/** Uploads a picked file to [remoteDir] on an FTP server running on the console (binary mode, passive). */
suspend fun ftpUpload(
    cr: ContentResolver, uri: Uri, host: String, port: Int,
    user: String, pass: String, remoteDir: String
): String = withContext(Dispatchers.IO) {
    val input = cr.openInputStream(uri) ?: return@withContext "Could not open file"
    val ftp = FTPClient()
    try {
        ftp.setConnectTimeout(5000)
        ftp.connect(host, port)
        if (!ftp.login(user, pass)) return@withContext "Login failed"
        ftp.enterLocalPassiveMode()
        ftp.setFileType(FTP.BINARY_FILE_TYPE)
        val remote = remoteDir.trimEnd('/') + "/" + cr.displayName(uri)
        val ok = input.use { ftp.storeFile(remote, it) }
        if (ok) "Uploaded to $remote" else "Upload failed: ${ftp.replyString}"
    } catch (e: Exception) {
        "Failed: ${e.message}"
    } finally {
        try {
            if (ftp.isConnected) {
                ftp.logout()
                ftp.disconnect()
            }
        } catch (_: Exception) {
        }
    }
}
