package com.example.pssender // change to match your project's package name

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

private val http = OkHttpClient.Builder()
    .connectTimeout(5, TimeUnit.SECONDS)
    .readTimeout(10, TimeUnit.SECONDS)
    .build()

/** Display name of a file picked through the system file picker. */
fun ContentResolver.displayName(uri: Uri): String =
    query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: "file"

/** Size in bytes of a picked file, or -1 when the provider doesn't say. */
fun fileSize(cr: ContentResolver, uri: Uri): Long =
    cr.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
        if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else -1L
    } ?: -1L

/** Human-readable size, e.g. 1.50 GB. */
fun fmtBytes(n: Long): String = when {
    n >= 1L shl 30 -> "%.2f GB".format(n / 1073741824.0)
    n >= 1L shl 20 -> "%.1f MB".format(n / 1048576.0)
    n >= 1L shl 10 -> "%.0f KB".format(n / 1024.0)
    else -> "$n B"
}

/**
 * Asks the console's package-installer service (port 12800 on etaHEN) to install a package from a URL.
 * 1) etaHEN style: multipart POST /upload with a "url" field; success text contains "SUCCESS:".
 * 2) Remote Package Installer style: POST /api/install with {"type":"direct","packages":[...]}.
 * Formats are taken from public documentation of existing installer tools; verify against your console.
 */
suspend fun sendInstall(host: String, port: String, pkgUrl: String): String =
    withContext(Dispatchers.IO) {
        val base = "http://$host:$port"
        try {
            val form = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("file", "", "".toRequestBody("application/octet-stream".toMediaType()))
                .addFormDataPart("url", pkgUrl)
                .build()
            val first = http.newCall(Request.Builder().url("$base/upload").post(form).build())
                .execute().use { it.code to it.body?.string().orEmpty() }
            if (first.second.contains("SUCCESS:")) {
                return@withContext "Installer accepted it: ${first.second.trim()}"
            }

            // RPI-style: URL-encoded, with the https scheme swapped to http
            val encoded = URLEncoder.encode(pkgUrl, "UTF-8").replace("https%3A", "http%3A")
            val json = JSONObject().put("type", "direct").put("packages", JSONArray().put(encoded)).toString()
            val second = http.newCall(
                Request.Builder().url("$base/api/install")
                    .post(json.toRequestBody("text/plain; charset=utf-8".toMediaType())).build()
            ).execute().use { it.code to it.body?.string().orEmpty() }
            if (second.second.contains("success")) {
                "Installer accepted it: ${second.second.trim()}"
            } else {
                "Not accepted (upload ${first.first}: ${first.second.take(80)}; api ${second.first}: ${second.second.take(80)})"
            }
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
    }

/**
 * Sends a file's raw bytes over TCP to a payload/ELF loader already listening on the console,
 * then closes the write side so the loader sees end-of-file.
 */
suspend fun sendPayload(cr: ContentResolver, uri: Uri, host: String, port: Int): String =
    withContext(Dispatchers.IO) {
        val input = cr.openInputStream(uri) ?: return@withContext "Could not open file"
        try {
            input.use { ins ->
                Socket().use { sock ->
                    sock.connect(InetSocketAddress(host, port), 5000)
                    val out = sock.getOutputStream()
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        total += n
                    }
                    out.flush()
                    sock.shutdownOutput()
                    "Sent $total bytes"
                }
            }
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
    }

// ---------------------------------------------------------------------------------------------
// Connection test
// ---------------------------------------------------------------------------------------------

/** True when something accepts a TCP connection on [host]:[port]. It connects and closes; nothing is sent. */
suspend fun isPortOpen(host: String, port: Int, timeoutMs: Int = 1500): Boolean =
    withContext(Dispatchers.IO) {
        try {
            Socket().use { sock ->
                sock.connect(InetSocketAddress(host, port), timeoutMs)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

/** Checks every (name, port) pair at the same time and returns a one-line summary like "✅ FTP 2121". */
suspend fun testConnection(host: String, checks: List<Pair<String, Int?>>): String = coroutineScope {
    val lines = checks.map { (name, port) ->
        async {
            val ok = port != null && isPortOpen(host, port)
            val label = if (port != null) "$name $port" else "$name (bad port)"
            (if (ok) "✅ " else "❌ ") + label
        }
    }.awaitAll()
    var text = lines.joinToString("  ·  ")
    if (lines.none { it.startsWith("✅") }) {
        text += "\nNothing answered. Check the console IP, that the PS5 is awake on the same Wi-Fi, and that etaHEN is running."
    }
    text
}

// ---------------------------------------------------------------------------------------------
// FTP transfers with progress (blocking: they run inside TransferService, off the main thread)
// ---------------------------------------------------------------------------------------------

/** Wraps a stream so the number of bytes read is reported, and a cancel request stops the transfer. */
private class CountingInputStream(
    inner: InputStream,
    private val total: Long,
    private val onProgress: (Long, Long) -> Unit
) : FilterInputStream(inner) {
    private var done = 0L
    private var lastReport = 0L

    override fun read(): Int {
        val b = super.read()
        if (b >= 0) count(1L)
        return b
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val n = super.read(b, off, len)
        if (n > 0) count(n.toLong())
        return n
    }

    private fun count(n: Long) {
        if (TransferState.cancelRequested) throw IOException("Cancelled")
        done += n
        val now = System.nanoTime()
        if (now - lastReport > 250_000_000L) {
            lastReport = now
            onProgress(done, total)
        }
    }

    /** Reports the final count right away (the regular reports are rate-limited). */
    fun report() = onProgress(done, total)
}

/** Connects, logs in and stores [input] as [remote]. Returns null on success, otherwise an error message. */
private fun ftpStore(
    ftp: FTPClient, input: InputStream, size: Long, remote: String,
    host: String, port: Int, user: String, pass: String,
    onProgress: (Long, Long) -> Unit
): String? {
    ftp.setConnectTimeout(5000)
    ftp.connect(host, port)
    if (!ftp.login(user, pass)) return "FTP login failed"
    ftp.enterLocalPassiveMode()
    ftp.setFileType(FTP.BINARY_FILE_TYPE)
    val counted = CountingInputStream(input, size, onProgress)
    val ok = counted.use { ftp.storeFile(remote, it) }
    counted.report()
    return if (ok) null else "FTP upload failed: ${ftp.replyString.trim()}"
}

/**
 * Runs [work] with a fresh FTP client and turns the outcome into a message. Registers an abort hook so
 * [TransferState.requestCancel] can close the connection immediately, even when the network has stalled.
 */
private fun runFtpJob(remote: String, work: (FTPClient) -> String?): String {
    val ftp = FTPClient()
    TransferState.abortHook = {
        try {
            ftp.disconnect()
        } catch (_: Exception) {
        }
    }
    return try {
        work(ftp) ?: "Sent to PS5: $remote"
    } catch (e: Exception) {
        if (TransferState.cancelRequested) {
            "Cancelled. A partial file may remain at $remote"
        } else {
            "Failed: ${e.message}"
        }
    } finally {
        TransferState.abortHook = null
        try {
            if (ftp.isConnected) {
                ftp.logout()
                ftp.disconnect()
            }
        } catch (_: Exception) {
        }
    }
}

/** Uploads [input] (a picked file) to [remoteDir]/[remoteName] on the console's FTP server. */
fun ftpUploadStream(
    input: InputStream, size: Long, remoteName: String,
    host: String, port: Int, user: String, pass: String, remoteDir: String,
    onProgress: (Long, Long) -> Unit
): String {
    val remote = remoteDir.trimEnd('/') + "/" + remoteName
    return runFtpJob(remote) { ftp ->
        ftpStore(ftp, input, size, remote, host, port, user, pass, onProgress)
    }
}

/**
 * Downloads [url] on the phone and streams it straight to the console's FTP server, without saving a copy
 * on the phone. [cookie] lets links that need a logged-in session work.
 */
fun ftpUploadFromUrl(
    url: String, userAgent: String, cookie: String?, fileName: String,
    host: String, port: Int, user: String, pass: String, remoteDir: String,
    onProgress: (Long, Long) -> Unit
): String {
    val remote = remoteDir.trimEnd('/') + "/" + fileName
    return runFtpJob(remote) { ftp ->
        val rb = Request.Builder().url(url).header("User-Agent", userAgent)
        if (!cookie.isNullOrEmpty()) rb.header("Cookie", cookie)
        val call = http.newCall(rb.build())
        TransferState.abortHook = {
            call.cancel()
            try {
                ftp.disconnect()
            } catch (_: Exception) {
            }
        }
        call.execute().use { resp ->
            if (!resp.isSuccessful) return@runFtpJob "Download failed: HTTP ${resp.code}"
            val body = resp.body ?: return@runFtpJob "Download failed: empty response"
            ftpStore(ftp, body.byteStream(), body.contentLength(), remote, host, port, user, pass, onProgress)
        }
    }
}
