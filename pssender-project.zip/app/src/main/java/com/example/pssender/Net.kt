package com.example.pssender // change to match your project's package name

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.apache.commons.net.DefaultSocketFactory
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPClientConfig
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.FilterOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.ConnectException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URLEncoder
import java.time.Duration
import java.util.concurrent.TimeUnit

private val http = OkHttpClient.Builder()
    .connectTimeout(5, TimeUnit.SECONDS)
    .readTimeout(10, TimeUnit.SECONDS)
    .build()

/** Display name of a file picked through the system file picker. */
fun ContentResolver.displayName(uri: Uri): String =
    query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: "file"

/** Size in bytes of a picked file, or -1 when the provider doesn't say. */
fun fileSize(cr: ContentResolver, uri: Uri): Long =
    cr.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
        if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else -1L
    } ?: -1L

/** Human-readable size, e.g. 1.50 GB. */
fun fmtBytes(n: Long): String = when {
    n >= 1L shl 30 -> "%.2f GB".format(n / 1073741824.0)
    n >= 1L shl 20 -> "%.1f MB".format(n / 1048576.0)
    n >= 1L shl 10 -> "%.0f KB".format(n / 1024.0)
    else -> "$n B"
}

/**
 * Asks the console's package-installer service (port 12800 on etaHEN) to install a package from a URL.
 * 1) etaHEN style: multipart POST /upload with a "url" field; success text contains "SUCCESS:".
 * 2) Remote Package Installer style: POST /api/install with {"type":"direct","packages":[...]}.
 * Formats are taken from public documentation of existing installer tools; verify against your console.
 */
suspend fun sendInstall(host: String, port: String, pkgUrl: String): String =
    withContext(Dispatchers.IO) {
        val base = "http://$host:$port"
        try {
            val form = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("file", "", "".toRequestBody("application/octet-stream".toMediaType()))
                .addFormDataPart("url", pkgUrl)
                .build()
            val first = http.newCall(Request.Builder().url("$base/upload").post(form).build())
                .execute().use { it.code to it.body?.string().orEmpty() }
            if (first.second.contains("SUCCESS:")) {
                return@withContext AppText.get(R.string.install_accepted, first.second.trim())
            }

            // RPI-style: URL-encoded, with the https scheme swapped to http
            val encoded = URLEncoder.encode(pkgUrl, "UTF-8").replace("https%3A", "http%3A")
            val json = JSONObject().put("type", "direct").put("packages", JSONArray().put(encoded)).toString()
            val second = http.newCall(
                Request.Builder().url("$base/api/install")
                    .post(json.toRequestBody("text/plain; charset=utf-8".toMediaType())).build()
            ).execute().use { it.code to it.body?.string().orEmpty() }
            if (second.second.contains("success")) {
                AppText.get(R.string.install_accepted, second.second.trim())
            } else {
                AppText.get(
                    R.string.install_not_accepted,
                    first.first.toString(), first.second.take(80), second.first.toString(), second.second.take(80)
                )
            }
        } catch (e: Exception) {
            failedText(e)
        }
    }

// ---------------------------------------------------------------------------------------------
// Payload sending
// ---------------------------------------------------------------------------------------------

/**
 * Blocking: streams [input] over TCP to a payload/ELF loader already listening on the console, then closes the
 * write side so the loader sees end-of-file. Returns "Sent 1.5 MB" (in the app's language).
 */
fun sendBytesToLoader(input: InputStream, host: String, port: Int): String =
    Socket().use { sock ->
        sock.connect(InetSocketAddress(host, port), 5000)
        val out = sock.getOutputStream()
        val buf = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            total += n
        }
        out.flush()
        sock.shutdownOutput()
        AppText.get(R.string.payload_sent, fmtBytes(total))
    }

/** Sends a file picked with the system file picker to the payload loader. */
suspend fun sendPayload(cr: ContentResolver, uri: Uri, host: String, port: Int): String =
    withContext(Dispatchers.IO) {
        val input = cr.openInputStream(uri) ?: return@withContext AppText.get(R.string.err_open_file)
        try {
            input.use { sendBytesToLoader(it, host, port) }
        } catch (e: Exception) {
            failedText(e)
        }
    }

/** Sends a payload stored on the shelf (see Shelf.kt) to the payload loader. */
suspend fun sendPayloadFile(file: File, host: String, port: Int): String =
    withContext(Dispatchers.IO) {
        try {
            FileInputStream(file).use { sendBytesToLoader(it, host, port) }
        } catch (e: Exception) {
            failedText(e)
        }
    }

/**
 * Downloads [url] on the phone straight into the payload shelf. Returns a message for the status line.
 * [cookie] lets links that need a logged-in session work.
 */
suspend fun shelfAddFromUrl(ctx: Context, url: String, userAgent: String, cookie: String?, fileName: String): String =
    withContext(Dispatchers.IO) {
        try {
            val rb = Request.Builder().url(url).header("User-Agent", userAgent)
            if (!cookie.isNullOrEmpty()) rb.header("Cookie", cookie)
            http.newCall(rb.build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext AppText.get(R.string.dl_http_failed, resp.code.toString())
                val body = resp.body ?: return@withContext AppText.get(R.string.dl_empty)
                val len = body.contentLength()
                if (len > SHELF_MAX_BYTES) {
                    return@withContext AppText.get(R.string.shelf_too_large_url, fmtBytes(len), fmtBytes(SHELF_MAX_BYTES))
                }
                shelfAddedMessage(body.byteStream().use { shelfAdd(shelfDir(ctx), fileName, it) })
            }
        } catch (e: ShelfTooLarge) {
            shelfTooLargeMessage(e.limit)
        } catch (e: Exception) {
            failedText(e)
        }
    }

// ---------------------------------------------------------------------------------------------
// Is a port open
// ---------------------------------------------------------------------------------------------

/** True when something accepts a TCP connection on [host]:[port]. It connects and closes; nothing is sent. */
suspend fun isPortOpen(host: String, port: Int, timeoutMs: Int = 1500): Boolean =
    withContext(Dispatchers.IO) {
        try {
            Socket().use { sock ->
                sock.connect(InetSocketAddress(host, port), timeoutMs)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

// ---------------------------------------------------------------------------------------------
// FTP: settings, paths and shared plumbing
// ---------------------------------------------------------------------------------------------

/** "Failed: <reason>" in the app's language. Falls back to the kind of error when it carries no message. */
fun failedText(e: Exception): String = AppText.get(R.string.err_failed, e.message ?: e.javaClass.simpleName)

/**
 * Message for a failed FTP command; adds advice about the FTP port when the console couldn't be reached at all
 * (the usual cause).
 */
fun ftpFailureMessage(e: Exception): String =
    failedText(e) + if (e is ConnectException || e is SocketTimeoutException) "\n" + AppText.get(R.string.ftp_port_hint) else ""

/** Where and how to log in to the console's FTP server. */
data class FtpSettings(val host: String, val port: Int, val user: String, val pass: String)

/** One row of a folder listing. [size] is in bytes (0 for folders). */
data class FtpEntry(val name: String, val isDir: Boolean, val isLink: Boolean, val size: Long)

/** A folder listing: the folder's path as the server reports it, and its entries (folders first). */
data class FtpListing(val path: String, val entries: List<FtpEntry>)

/** "/data" + "a.txt" -> "/data/a.txt" (never a doubled slash). */
fun joinPath(dir: String, name: String): String = if (dir.endsWith("/")) dir + name else "$dir/$name"

/** "/data/games" -> "/data", "/data" -> "/", "/" -> "/". */
fun parentPath(path: String): String {
    val t = path.trimEnd('/')
    val i = t.lastIndexOf('/')
    return if (i <= 0) "/" else t.substring(0, i)
}

/** Null when [name] is fine for a file or folder on the console, otherwise the reason it isn't. */
fun badRemoteName(name: String): String? = when {
    name.isBlank() -> AppText.get(R.string.name_empty)
    name == "." || name == ".." -> AppText.get(R.string.name_not_allowed)
    name.contains('/') || name.contains('\\') -> AppText.get(R.string.name_slash)
    name.any { it.isISOControl() } -> AppText.get(R.string.name_control)
    else -> null
}

/** Folders first, then everything else, each group in alphabetical order. */
fun sortEntries(entries: List<FtpEntry>): List<FtpEntry> =
    entries.sortedWith(compareBy<FtpEntry>({ !it.isDir }, { it.name.lowercase() }))

/** Connects and logs in. Returns null when ready, otherwise the reason it isn't. */
private fun ftpConnect(ftp: FTPClient, s: FtpSettings): String? {
    ftp.setConnectTimeout(5000)
    ftp.connect(s.host, s.port)
    if (!ftp.login(s.user, s.pass)) return AppText.get(R.string.err_login)
    ftp.enterLocalPassiveMode()
    ftp.setFileType(FTP.BINARY_FILE_TYPE)
    return null
}

/**
 * Runs [block] on a freshly connected client and always disconnects afterwards. Meant for short commands
 * (list, rename, delete, ...), so it gives up on a console that stops answering instead of waiting forever.
 */
private fun <T> withFtp(s: FtpSettings, block: (FTPClient) -> T): T {
    val ftp = FTPClient()
    // Console FTP servers print folders in the usual Unix "ls -l" style; this also skips the SYST guessing
    ftp.configure(FTPClientConfig(FTPClientConfig.SYST_UNIX))
    ftp.setDefaultTimeout(30000)
    ftp.setDataTimeout(Duration.ofSeconds(30))
    try {
        ftpConnect(ftp, s)?.let { throw IOException(it) }
        return block(ftp)
    } finally {
        try {
            if (ftp.isConnected) {
                ftp.logout()
                ftp.disconnect()
            }
        } catch (_: Exception) {
        }
    }
}

// ---------------------------------------------------------------------------------------------
// FTP: browsing and file management
// ---------------------------------------------------------------------------------------------

private fun listFolder(ftp: FTPClient, path: String): FtpListing {
    if (!ftp.changeWorkingDirectory(path)) throw IOException(AppText.get(R.string.err_cant_open, path, ftp.replyString.trim()))
    val here = ftp.printWorkingDirectory() ?: path
    val entries = ftp.listFiles().orEmpty().filterNotNull()
        .filter { !it.name.isNullOrEmpty() && it.name != "." && it.name != ".." }
        .map { f ->
            FtpEntry(
                name = f.name,
                isDir = f.isDirectory,
                isLink = f.isSymbolicLink,
                size = if (f.isDirectory) 0L else f.size.coerceAtLeast(0L)
            )
        }
    return FtpListing(here, sortEntries(entries))
}

/** Lists the folder [path] on the console. Throws IOException with a readable message when it can't. */
fun ftpList(s: FtpSettings, path: String): FtpListing = withFtp(s) { ftp -> listFolder(ftp, path) }

/** Renames [from] to [to] inside the folder [dir]. */
fun ftpRename(s: FtpSettings, dir: String, from: String, to: String) {
    withFtp(s) { ftp ->
        if (!ftp.rename(joinPath(dir, from), joinPath(dir, to))) {
            throw IOException(AppText.get(R.string.err_rename, ftp.replyString.trim()))
        }
    }
}

/** Creates the folder [name] inside [dir]. */
fun ftpMakeDir(s: FtpSettings, dir: String, name: String) {
    withFtp(s) { ftp ->
        if (!ftp.makeDirectory(joinPath(dir, name))) {
            throw IOException(AppText.get(R.string.err_mkdir, ftp.replyString.trim()))
        }
    }
}

/** Deletes a folder with everything inside it. Links are removed, never followed. Returns the number of items removed. */
private fun deleteTree(ftp: FTPClient, path: String, depth: Int): Int {
    if (depth > 40) throw IOException(AppText.get(R.string.err_too_deep))
    var removed = 0
    for (e in listFolder(ftp, path).entries) {
        val child = joinPath(path, e.name)
        if (e.isDir) {
            removed += deleteTree(ftp, child, depth + 1)
        } else {
            if (!ftp.deleteFile(child)) throw IOException(AppText.get(R.string.err_delete_path, child, ftp.replyString.trim()))
            removed++
        }
    }
    // Step out first: some servers refuse to remove the folder they are currently inside
    ftp.changeWorkingDirectory("/")
    if (!ftp.removeDirectory(path)) throw IOException(AppText.get(R.string.err_delete_path, path, ftp.replyString.trim()))
    return removed + 1
}

/** Deletes [entry] from the folder [dir]; a folder goes with everything inside it. Returns how many items were removed. */
fun ftpDelete(s: FtpSettings, dir: String, entry: FtpEntry): Int =
    withFtp(s) { ftp ->
        val full = joinPath(dir, entry.name)
        if (entry.isDir) {
            deleteTree(ftp, full, 0)
        } else {
            if (!ftp.deleteFile(full)) throw IOException(AppText.get(R.string.err_delete_path, entry.name, ftp.replyString.trim()))
            1
        }
    }

// ---------------------------------------------------------------------------------------------
// FTP transfers with progress (blocking: they run inside TransferService, off the main thread)
// ---------------------------------------------------------------------------------------------

/** Counts bytes, reports progress at most every 250 ms, and aborts the transfer once a cancel was requested. */
private class ProgressMeter(private val total: Long, private val onProgress: (Long, Long) -> Unit) {
    private var done = 0L
    private var lastReport = 0L

    fun add(n: Long) {
        if (TransferState.cancelRequested) throw IOException("Cancelled")
        done += n
        val now = System.nanoTime()
        if (now - lastReport > 250_000_000L) {
            lastReport = now
            onProgress(done, total)
        }
    }

    /** Reports the final count right away (the regular reports are rate-limited). */
    fun report() = onProgress(done, total)
}

/** Wraps a stream being uploaded so progress is reported and a cancel request stops the transfer. */
private class CountingInputStream(
    inner: InputStream,
    total: Long,
    onProgress: (Long, Long) -> Unit
) : FilterInputStream(inner) {
    private val meter = ProgressMeter(total, onProgress)

    override fun read(): Int {
        val b = super.read()
        if (b >= 0) meter.add(1L)
        return b
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val n = super.read(b, off, len)
        if (n > 0) meter.add(n.toLong())
        return n
    }

    fun report() = meter.report()
}

/** Wraps the stream a download is written to so progress is reported and a cancel request stops the transfer. */
private class CountingOutputStream(
    inner: OutputStream,
    total: Long,
    onProgress: (Long, Long) -> Unit
) : FilterOutputStream(inner) {
    private val meter = ProgressMeter(total, onProgress)

    override fun write(b: Int) {
        out.write(b)
        meter.add(1L)
    }

    // FilterOutputStream would otherwise write one byte at a time
    override fun write(b: ByteArray, off: Int, len: Int) {
        out.write(b, off, len)
        meter.add(len.toLong())
    }

    fun report() = meter.report()
}

/** Connects, logs in and stores [input] as [remote]. Returns null on success, otherwise an error message. */
private fun ftpStore(
    ftp: FTPClient, input: InputStream, size: Long, remote: String, s: FtpSettings,
    onProgress: (Long, Long) -> Unit
): String? {
    ftpConnect(ftp, s)?.let { return it }
    val counted = CountingInputStream(input, size, onProgress)
    val ok = counted.use { ftp.storeFile(remote, it) }
    counted.report()
    return if (ok) null else AppText.get(R.string.err_upload, ftp.replyString.trim())
}

/** Connects, logs in and writes [remote] into [out] (which is closed afterwards). Null on success, otherwise an error message. */
private fun ftpRetrieve(
    ftp: FTPClient, out: OutputStream, size: Long, remote: String, s: FtpSettings,
    onProgress: (Long, Long) -> Unit
): String? {
    val counted = CountingOutputStream(out, size, onProgress)
    return counted.use { sink ->
        ftpConnect(ftp, s) ?: run {
            val ok = ftp.retrieveFile(remote, sink)
            counted.report()
            if (ok) null else AppText.get(R.string.err_download, ftp.replyString.trim())
        }
    }
}

/**
 * Remembers every socket the FTP client opens (the login connection and each data connection), so a cancel can
 * close them all. Closing only the login connection would leave a transfer that is stuck in a blocked read or
 * write hanging.
 */
private class TrackingSocketFactory : DefaultSocketFactory() {
    private val sockets = mutableListOf<Socket>()

    private fun track(s: Socket): Socket {
        synchronized(sockets) { sockets.add(s) }
        return s
    }

    override fun createSocket(): Socket = track(super.createSocket())
    override fun createSocket(host: String, port: Int): Socket = track(super.createSocket(host, port))
    override fun createSocket(host: String, port: Int, localAddr: InetAddress, localPort: Int): Socket =
        track(super.createSocket(host, port, localAddr, localPort))
    override fun createSocket(address: InetAddress, port: Int): Socket = track(super.createSocket(address, port))
    override fun createSocket(address: InetAddress, port: Int, localAddr: InetAddress, localPort: Int): Socket =
        track(super.createSocket(address, port, localAddr, localPort))

    fun closeAll() {
        val all = synchronized(sockets) { sockets.toList() }
        for (s in all) {
            try {
                s.close()
            } catch (_: Exception) {
            }
        }
    }
}

/** One FTP client whose connections can all be shut at once. */
private class FtpSession {
    private val factory = TrackingSocketFactory()
    val ftp = FTPClient().also { it.setSocketFactory(factory) }

    /** Closes every connection, which also frees a thread stuck waiting on a stalled network. Safe to call twice. */
    fun abort() {
        factory.closeAll()
        try {
            ftp.disconnect()
        } catch (_: Exception) {
        }
    }
}

/** How a transfer ended: [ok] is true when it worked, and [message] is what to tell the user (in the app's language). */
data class TransferResult(val ok: Boolean, val message: String)

/**
 * Runs [work] with a fresh FTP session and turns the outcome into a [TransferResult]. [work] returns null when it
 * worked, otherwise the reason it didn't. Registers an abort hook so [TransferState.requestCancel] can close the
 * connections immediately, even when the network has stalled.
 */
private fun runFtpJobResult(okMessage: String, cancelMessage: String, work: (FtpSession) -> String?): TransferResult {
    val session = FtpSession()
    TransferState.abortHook = { session.abort() }
    return try {
        val problem = work(session)
        if (problem == null) TransferResult(true, okMessage) else TransferResult(false, problem)
    } catch (e: Exception) {
        if (TransferState.cancelRequested) TransferResult(false, cancelMessage) else TransferResult(false, failedText(e))
    } finally {
        // Say goodbye politely, but never wait long for a console that has stopped answering
        try {
            if (session.ftp.isConnected) {
                session.ftp.setSoTimeout(5000)
                session.ftp.logout()
            }
        } catch (_: Exception) {
        }
        session.abort()
        TransferState.abortHook = null
    }
}

private fun runFtpJob(remote: String, work: (FtpSession) -> String?): TransferResult =
    runFtpJobResult(AppText.get(R.string.sent_to_ps5, remote), AppText.get(R.string.err_cancelled_upload, remote), work)

/** Uploads [input] (a picked file) to [remoteDir]/[remoteName] on the console's FTP server. */
fun ftpUploadStream(
    input: InputStream, size: Long, remoteName: String,
    host: String, port: Int, user: String, pass: String, remoteDir: String,
    onProgress: (Long, Long) -> Unit
): TransferResult {
    val remote = remoteDir.trimEnd('/') + "/" + remoteName
    val s = FtpSettings(host, port, user, pass)
    return runFtpJob(remote) { session -> ftpStore(session.ftp, input, size, remote, s, onProgress) }
}

/**
 * Downloads [url] on the phone and streams it straight to the console's FTP server, without saving a copy
 * on the phone. [cookie] lets links that need a logged-in session work.
 */
fun ftpUploadFromUrl(
    url: String, userAgent: String, cookie: String?, fileName: String,
    host: String, port: Int, user: String, pass: String, remoteDir: String,
    onProgress: (Long, Long) -> Unit
): TransferResult {
    val remote = remoteDir.trimEnd('/') + "/" + fileName
    val s = FtpSettings(host, port, user, pass)
    return runFtpJob(remote) { session ->
        val rb = Request.Builder().url(url).header("User-Agent", userAgent)
        if (!cookie.isNullOrEmpty()) rb.header("Cookie", cookie)
        val call = http.newCall(rb.build())
        TransferState.abortHook = {
            call.cancel()
            session.abort()
        }
        call.execute().use { resp ->
            if (!resp.isSuccessful) return@runFtpJob AppText.get(R.string.dl_http_failed, resp.code.toString())
            val body = resp.body ?: return@runFtpJob AppText.get(R.string.dl_empty)
            ftpStore(session.ftp, body.byteStream(), body.contentLength(), remote, s, onProgress)
        }
    }
}

/**
 * Downloads [remote] from the console into [out] (closed afterwards). Returns how it ended; [okMessage] is the
 * message for a download that worked. [size] is used for the progress bar and may be -1 when unknown.
 */
fun ftpDownloadToStream(
    out: OutputStream, size: Long, remote: String, s: FtpSettings, okMessage: String,
    onProgress: (Long, Long) -> Unit
): TransferResult =
    runFtpJobResult(okMessage, AppText.get(R.string.err_cancelled_download)) { session ->
        ftpRetrieve(session.ftp, out, size, remote, s, onProgress)
    }

/**
 * Downloads [remote] from the console into the phone's Downloads/PS5 folder (a MediaStore entry, so no storage
 * permission is needed). A failed or cancelled download leaves nothing behind.
 */
fun ftpDownloadToPhone(
    cr: ContentResolver, remote: String, name: String, size: Long, s: FtpSettings,
    onProgress: (Long, Long) -> Unit
): TransferResult {
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
        ?: "application/octet-stream"
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        put(MediaStore.MediaColumns.MIME_TYPE, mime)
        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PS5")
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        ?: return TransferResult(false, AppText.get(R.string.dl_create_failed))
    var saved = false
    try {
        val out = cr.openOutputStream(uri) ?: return TransferResult(false, AppText.get(R.string.dl_write_failed))
        val result = ftpDownloadToStream(out, size, remote, s, AppText.get(R.string.saved_to_downloads, name), onProgress)
        saved = result.ok
        return result
    } finally {
        try {
            if (saved) {
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                cr.update(uri, done, null, null)
            } else {
                cr.delete(uri, null, null)
            }
        } catch (_: Exception) {
        }
    }
}
