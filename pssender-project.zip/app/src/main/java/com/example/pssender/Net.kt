package com.example.pssender // change to match your project's package name

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit

private val http = OkHttpClient.Builder()
    .connectTimeout(5, TimeUnit.SECONDS)
    .readTimeout(10, TimeUnit.SECONDS)
    .build()

/** Display name of a file picked through the system file picker. */
fun ContentResolver.displayName(uri: Uri): String =
    query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: "file"

/**
 * Placeholder protocol: POST http://<host>:<port>/install  {"url": "<package url>"}
 * The PS5-side listener will be written to match this, so it can still change.
 */
suspend fun sendInstall(host: String, port: String, pkgUrl: String): String =
    withContext(Dispatchers.IO) {
        val body = JSONObject().put("url", pkgUrl).toString()
            .toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url("http://$host:$port/install").post(body).build()
        try {
            http.newCall(req).execute().use { "${it.code}: ${it.body?.string().orEmpty()}" }
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
    }

/**
 * Sends a file's raw bytes over TCP to a payload/ELF loader already listening on the console,
 * then closes the write side so the loader sees end-of-file.
 */
suspend fun sendPayload(cr: ContentResolver, uri: Uri, host: String, port: Int): String =
    withContext(Dispatchers.IO) {
        val input = cr.openInputStream(uri) ?: return@withContext "Could not open file"
        try {
            input.use { ins ->
                Socket().use { sock ->
                    sock.connect(InetSocketAddress(host, port), 5000)
                    val out = sock.getOutputStream()
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        total += n
                    }
                    out.flush()
                    sock.shutdownOutput()
                    "Sent $total bytes"
                }
            }
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
    }

/** Uploads a picked file to [remoteDir] on an FTP server running on the console (binary mode, passive). */
suspend fun ftpUpload(
    cr: ContentResolver, uri: Uri, host: String, port: Int,
    user: String, pass: String, remoteDir: String
): String = withContext(Dispatchers.IO) {
    val input = cr.openInputStream(uri) ?: return@withContext "Could not open file"
    val ftp = FTPClient()
    try {
        ftp.setConnectTimeout(5000)
        ftp.connect(host, port)
        if (!ftp.login(user, pass)) return@withContext "Login failed"
        ftp.enterLocalPassiveMode()
        ftp.setFileType(FTP.BINARY_FILE_TYPE)
        val remote = remoteDir.trimEnd('/') + "/" + cr.displayName(uri)
        val ok = input.use { ftp.storeFile(remote, it) }
        if (ok) "Uploaded to $remote" else "Upload failed: ${ftp.replyString}"
    } catch (e: Exception) {
        "Failed: ${e.message}"
    } finally {
        try {
            if (ftp.isConnected) {
                ftp.logout()
                ftp.disconnect()
            }
        } catch (_: Exception) {
        }
    }
}
