package com.example.pssender // change to match your project's package name

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------------------------------------
// The frame around every screen: header, console card, status line, transfer card and bottom bar
// ---------------------------------------------------------------------------------------------

/** A small filled circle, used as a status light. */
@Composable
fun StatusDot(color: Color, size: Dp = 10.dp) {
    Box(Modifier.size(size).background(color, CircleShape))
}

/** A small hollow circle: the same light turned off, so "off" doesn't rely on color alone. */
@Composable
fun StatusRing(color: Color, size: Dp = 10.dp) {
    Box(Modifier.size(size).border(2.dp, color, CircleShape))
}

/** The selected console, shown as a pill in the accent color of that console. Tap to switch consoles. */
@Composable
fun ConsoleChip(name: String, accent: Color, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .widthIn(max = 190.dp)
            .clip(CircleShape)
            .border(1.dp, cs.outlineVariant, CircleShape)
            .clickable(onClickLabel = "Switch console", onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatusDot(accent)
        Text(
            name,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
        Text("▾", color = cs.onSurfaceVariant, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun AppHeader(consoleName: String, accent: Color, onConsoles: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("PS5 Sender", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        ConsoleChip(consoleName, accent, onConsoles)
    }
}

/** One service on the console card: a light and its name. A filled light answers, a hollow one doesn't. */
@Composable
private fun ServicePill(check: ServiceCheck, level: ConsoleLevel, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val sc = statusColors()
    val state: Boolean? = if (check.port == null) null else check.up
    Row(
        modifier = modifier.clip(CircleShape).background(cs.surface).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally)
    ) {
        when (state) {
            true -> StatusDot(sc.good, 8.dp)
            false -> StatusRing(if (level == ConsoleLevel.OFFLINE) sc.bad else sc.warn, 8.dp)
            null -> StatusRing(cs.onSurfaceVariant, 8.dp)
        }
        Text(check.label, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/**
 * Shows whether the selected console is reachable: a colored light and title, the address, and (unless
 * [compact]) which services answer. Tap it to change the address.
 */
@Composable
fun ConsoleCard(
    host: String,
    level: ConsoleLevel,
    checks: List<ServiceCheck>,
    compact: Boolean,
    onEdit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val sc = statusColors()
    val tone = when (level) {
        ConsoleLevel.READY -> sc.good
        ConsoleLevel.PARTIAL -> sc.warn
        ConsoleLevel.OFFLINE -> sc.bad
        else -> cs.onSurfaceVariant
    }
    val down = checks.filter { it.port != null && it.up == false }.map { it.label }
    val hint = consoleHint(level, down)
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(cs.surfaceContainer)
            .border(1.dp, cs.outlineVariant, shape)
            .clickable(onClickLabel = "Change the IP address", onClick = onEdit)
            .padding(horizontal = 14.dp, vertical = if (compact) 10.dp else 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusDot(tone)
            Text(
                consoleHeadline(level, down, compact),
                color = tone,
                style = MaterialTheme.typography.titleMedium,
                maxLines = if (compact) 2 else 1, // the short card may need a second line to name what is off
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (host.isNotBlank()) {
                Text(
                    host,
                    color = cs.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 150.dp) // a long name must never squeeze the title away
                )
            }
            Text("›", color = cs.onSurfaceVariant, style = MaterialTheme.typography.titleMedium)
        }
        if (!compact) {
            if (level != ConsoleLevel.UNSET && checks.isNotEmpty()) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    checks.forEach { c -> ServicePill(c, level, Modifier.weight(1f)) }
                }
            }
            if (hint != null) {
                Text(hint, color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

/** Asks for the console's IP address. The change is saved as you type. */
@Composable
fun ConsoleEditDialog(host: String, onHostChange: (String) -> Unit, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Console IP address") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("IP address", host, onHostChange)
                Text(
                    "Find it on the PS5 under Settings > Network > Connection Status > View Connection Status.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } }
    )
}

/** One place the bottom bar can go to. */
class NavItem(val label: String, val icon: ImageVector)

/** The bottom bar: one button per screen, the current one in the accent color. */
@Composable
fun BottomBar(items: List<NavItem>, selected: Int, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(modifier = Modifier.fillMaxWidth().background(cs.surfaceContainer)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(cs.outlineVariant))
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp)) {
            items.forEachIndexed { i, item ->
                val on = i == selected
                val tint = if (on) cs.primary else cs.onSurfaceVariant
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .selectable(selected = on, role = Role.Tab, onClick = { onSelect(i) })
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (on) cs.primary.copy(alpha = 0.16f) else Color.Transparent)
                            .padding(horizontal = 18.dp, vertical = 4.dp)
                    ) {
                        Icon(item.icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
                    }
                    Text(
                        item.label,
                        color = tint,
                        fontSize = 12.sp,
                        fontWeight = if (on) FontWeight.Medium else FontWeight.Normal,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/** "Sending to My PS5 · 1.2 GB of 5 GB" for a running transfer. */
fun transferDetail(t: TransferInfo, console: String): String {
    val action = if (t.download) "Receiving" else "Sending"
    val where = if (console.isBlank()) action else "$action ${if (t.download) "from" else "to"} $console"
    return when {
        t.total > 0 -> "$where · ${fmtBytes(t.done)} of ${fmtBytes(t.total)}"
        t.done > 0 -> "$where · ${fmtBytes(t.done)}"
        else -> where
    }
}

/**
 * Progress of the current transfer, pinned above the bottom bar so it shows on every screen. While it runs there is a
 * Cancel button; when it ends the result stays until dismissed.
 */
@Composable
fun TransferCard(t: TransferInfo, console: String, onCancel: () -> Unit, onDismiss: () -> Unit) {
    if (t.label.isEmpty()) return
    val cs = MaterialTheme.colorScheme
    val sc = statusColors()
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(shape)
            .background(cs.surfaceContainerHigh)
            .border(1.dp, cs.outlineVariant, shape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (t.active) {
            val known = t.total > 0
            val fraction = if (known) (t.done.toFloat() / t.total.toFloat()).coerceIn(0f, 1f) else 0f
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    t.label,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text(if (known) "${(fraction * 100).toInt()}%" else fmtBytes(t.done), style = MaterialTheme.typography.titleSmall)
            }
            if (known) {
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier.fillMaxWidth(),
                    color = cs.primary,
                    trackColor = cs.surfaceVariant
                )
            } else {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = cs.primary,
                    trackColor = cs.surfaceVariant
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    transferDetail(t, console),
                    color = cs.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onCancel) { Text("Cancel") }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(
                    if (t.ok) CheckIcon else AlertIcon,
                    contentDescription = if (t.ok) "Done" else "Problem",
                    tint = if (t.ok) sc.good else sc.bad,
                    modifier = Modifier.size(24.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(t.label, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        t.message,
                        color = cs.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                TextButton(onClick = onDismiss) { Text("Dismiss") }
            }
        }
    }
}

/** The one-line answer to the last action ("Sending link to PS5…", "Installer accepted it", ...). Tap to hide. */
@Composable
fun StatusStrip(text: String, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(cs.surfaceVariant)
            .clickable(onClickLabel = "Hide this message", onClick = onDismiss)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text,
            color = cs.onSurface,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 6,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Text("✕", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}
